<?php
declare(strict_types=1);

/**
 * FRONT CONTROLLER — toda requisição entra por aqui.
 * 1) autoload das classes  2) sessão  3) rotas  4) despacha para o Controller
 */
define('BASE_PATH', dirname(__DIR__));

spl_autoload_register(function (string $classe): void {
    $prefixo = 'App\\';
    if (strncmp($classe, $prefixo, strlen($prefixo)) !== 0) return;
    $arquivo = BASE_PATH . '/app/' . str_replace('\\', '/', substr($classe, strlen($prefixo))) . '.php';
    if (is_file($arquivo)) require $arquivo;
});

require BASE_PATH . '/app/Core/helpers.php';

use App\Core\{Config, Router, Session, View};

if (Config::get('app.debug')) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    set_exception_handler(function (Throwable $e): void {
        error_log($e);
        http_response_code(500);
        View::render('erro/erro', ['codigo' => 500, 'mensagem' => 'Ocorreu um erro inesperado. Tente novamente.', 'titulo' => 'Erro'], 'publico');
    });
}

Session::iniciar();
Session::carregarOld();

$router = new Router();
require BASE_PATH . '/config/routes.php';
$router->despachar();
