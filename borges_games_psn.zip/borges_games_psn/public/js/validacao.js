/**
 * Validação de formulários no navegador + pequenos utilitários de interface.
 * (A validação do servidor — Validator.php — continua sendo a que vale.)
 *
 * Atributos usados nos formulários:
 *   data-validar            -> ativa a validação no <form>
 *   data-igual="idCampo"    -> o campo deve ser igual a outro (confirmação de senha)
 *   data-tipo="telefone"    -> exige DDD + número (10 ou 11 dígitos)
 *   data-mask="telefone"    -> máscara (99) 99999-9999
 *   data-confirmar="texto"  -> pede confirmação antes de enviar (ex.: excluir)
 *   data-max-mb="2"         -> tamanho máximo do arquivo no <input type=file>
 */
(function () {
    'use strict';

    // ---------- helpers ----------
    function limparErro(campo) {
        campo.classList.remove('invalido');
        const prox = campo.parentElement.querySelector('.campo-erro[data-de="' + campo.id + '"]');
        if (prox) prox.remove();
    }

    function mostrarErro(campo, msg) {
        limparErro(campo);
        campo.classList.add('invalido');
        const span = document.createElement('span');
        span.className = 'campo-erro';
        span.dataset.de = campo.id;
        span.textContent = msg;
        campo.insertAdjacentElement('afterend', span);
    }

    function mensagemDoCampo(campo) {
        const v = campo.value.trim();
        const nome = (campo.labels && campo.labels[0])
            ? campo.labels[0].textContent.replace('*', '').trim() : 'Campo';

        if (campo.required && v === '') return nome + ' é obrigatório.';
        if (v === '') return '';

        if (campo.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return 'Informe um e-mail válido.';
        if (campo.minLength > 0 && v.length < campo.minLength) return nome + ' deve ter no mínimo ' + campo.minLength + ' caracteres.';
        if (campo.type === 'number') {
            const n = parseFloat(v);
            if (isNaN(n)) return nome + ' deve ser um número.';
            if (campo.min !== '' && n < parseFloat(campo.min)) return nome + ' deve ser no mínimo ' + campo.min + '.';
            if (campo.max !== '' && n > parseFloat(campo.max)) return nome + ' deve ser no máximo ' + campo.max + '.';
        }
        if (campo.dataset.tipo === 'telefone') {
            const d = v.replace(/\D/g, '');
            if (d.length < 10 || d.length > 11) return 'Telefone inválido. Use DDD + número.';
        }
        if (campo.dataset.igual) {
            const outro = document.getElementById(campo.dataset.igual);
            if (outro && outro.value !== campo.value) return 'As senhas não coincidem.';
        }
        if (campo.type === 'file' && campo.files.length) {
            const max = parseFloat(campo.dataset.maxMb || '2') * 1024 * 1024;
            if (campo.files[0].size > max) return 'A imagem deve ter no máximo ' + (max / 1048576) + ' MB.';
            if (!/^image\/(jpeg|png|webp|gif)$/.test(campo.files[0].type)) return 'Use uma imagem JPG, PNG, WEBP ou GIF.';
        }
        return '';
    }

    function validarCampo(campo) {
        const msg = mensagemDoCampo(campo);
        msg ? mostrarErro(campo, msg) : limparErro(campo);
        return msg === '';
    }

    // ---------- validação ao enviar / ao sair do campo ----------
    document.querySelectorAll('form[data-validar]').forEach(function (form) {
        form.noValidate = true; // as mensagens são nossas
        const campos = form.querySelectorAll('input:not([type=hidden]):not([type=checkbox]), select, textarea');

        campos.forEach(function (c) {
            if (!c.id) c.id = 'c_' + Math.random().toString(36).slice(2, 8);
            c.addEventListener('blur', function () { validarCampo(c); });
            c.addEventListener('input', function () { if (c.classList.contains('invalido')) validarCampo(c); });
        });

        form.addEventListener('submit', function (e) {
            let ok = true, primeiro = null;
            campos.forEach(function (c) {
                if (c.disabled) return;
                if (!validarCampo(c)) { ok = false; primeiro = primeiro || c; }
            });
            if (!ok) { e.preventDefault(); e.stopImmediatePropagation(); primeiro.focus(); }
        });
    });

    // ---------- máscara de telefone ----------
    document.querySelectorAll('[data-mask="telefone"]').forEach(function (input) {
        function aplicar() {
            let d = input.value.replace(/\D/g, '').slice(0, 11);
            if (d.length > 10)      d = d.replace(/^(\d{2})(\d{5})(\d{4}).*/, '($1) $2-$3');
            else if (d.length > 6)  d = d.replace(/^(\d{2})(\d{4})(\d{0,4}).*/, '($1) $2-$3');
            else if (d.length > 2)  d = d.replace(/^(\d{2})(\d{0,5})/, '($1) $2');
            else if (d.length > 0)  d = d.replace(/^(\d*)/, '($1');
            input.value = d;
        }
        input.addEventListener('input', aplicar);
    });

    // ---------- confirmação antes de enviar (excluir etc.) ----------
    document.addEventListener('submit', function (e) {
        const f = e.target;
        if (!(f instanceof HTMLFormElement) || !f.dataset.confirmar) return;

        const se = f.dataset.confirmarSe; // só confirma se status == valor (ex.: "cancelado")
        if (se) {
            const campo = f.querySelector('[name="status"]');
            if (!campo || campo.value !== se) return;
        }
        if (!window.confirm(f.dataset.confirmar)) e.preventDefault();
    });

    // ---------- pré-visualização da imagem escolhida ----------
    const arq = document.getElementById('imagem');
    const prev = document.getElementById('previewImagem');
    if (arq && prev) {
        arq.addEventListener('change', function () {
            if (arq.files.length && arq.files[0].type.startsWith('image/')) {
                prev.src = URL.createObjectURL(arq.files[0]);
                prev.hidden = false;
            } else {
                prev.hidden = true;
            }
        });
    }
})();
