# Etapa 1 — Planejamento, modelagem e banco de dados

## 1. Tema
**Borges Games** — loja virtual de jogos digitais (estilo PlayStation Store).

## 2. Descrição do sistema
Aplicação web em PHP 8 (MVC + POO) com MySQL/PDO. O **público** navega no catálogo, busca por nome, filtra por categoria, vê os detalhes do jogo, monta um carrinho e, depois de criar conta e entrar, finaliza pedidos e acompanha o histórico. A **equipe** acessa um painel restrito com dashboard, CRUD completo de jogos, categorias, clientes, usuários e pedidos, além de relatório de vendas e controle de estoque.

## 3. Regras de negócio
| # | Regra |
|---|-------|
| RN01 | Há dois tipos de conta: **cliente** (cadastro público) e **usuário da equipe** (criado só pelo administrador). Cliente nunca vira administrador pelo cadastro. |
| RN02 | O e-mail é único em todo o sistema (não pode existir igual em `clientes` e `usuarios`). |
| RN03 | Senhas são gravadas com `password_hash()` e conferidas com `password_verify()`. Mínimo de 6 caracteres. |
| RN04 | Usuários da equipe têm papel **admin** (acesso total, inclusive usuários) ou **gerente** (tudo, menos usuários). |
| RN05 | O sistema sempre mantém ao menos 1 administrador ativo; ninguém exclui/desativa a si mesmo. |
| RN06 | Conta inativa não consegue entrar. Após 5 logins errados, o login é bloqueado por 60 s. |
| RN07 | Só jogos **ativos** aparecem na loja. Jogo com estoque 0 aparece como "Esgotado" e não vai ao carrinho. |
| RN08 | Cada jogo pertence a exatamente uma categoria. Categoria com jogos não pode ser excluída. |
| RN09 | Somente cliente logado finaliza compra; o carrinho é guardado na sessão. |
| RN10 | Ao criar o pedido, o estoque é **baixado** na mesma transação. Estoque insuficiente cancela a operação inteira. |
| RN11 | O item do pedido guarda o **preço do momento** da compra (mudar o preço depois não altera pedidos antigos). |
| RN12 | Status: `pendente` → `pago`; `pendente`/`pago` → `cancelado`. **Cancelar devolve o estoque**; pedido cancelado não pode ser reaberto. |
| RN13 | Jogo vendido (presente em pedidos) e cliente com pedidos não podem ser excluídos; usa-se "inativo". |
| RN14 | Excluir um pedido ainda ativo devolve o estoque. |
| RN15 | Relatórios e faturamento consideram apenas pedidos **pagos**. |
| RN16 | Cliente só enxerga os próprios pedidos. |

## 4. Diagrama de classes (UML)
```mermaid
classDiagram
    class Usuario {
        +int id
        +string nome
        +string email
        +string senha
        +string papel
        +bool ativo
        +autenticar(email, senha)
        +criar() / atualizar() / excluir()
    }
    class Cliente {
        +int id
        +string nome
        +string email
        +string telefone
        +string senha
        +bool ativo
        +autenticar(email, senha)
        +criar() / atualizar() / excluir()
    }
    class Categoria {
        +int id
        +string nome
        +string descricao
        +criar() / atualizar() / excluir()
    }
    class Game {
        +int id
        +string titulo
        +string descricao
        +decimal preco
        +int estoque
        +string imagem
        +bool destaque
        +bool ativo
        +listarPublico(busca, categoria)
        +criar() / atualizar() / excluir()
    }
    class Pedido {
        +int id
        +string status
        +string forma_pagamento
        +decimal total
        +datetime created_at
        +criar(cliente, itens)
        +atualizar(status)
        +excluir()
    }
    class ItemPedido {
        +int quantidade
        +decimal preco_unitario
    }
    class Carrinho {
        +adicionar() / atualizar() / remover()
        +itens() / total()
    }
    Categoria "1" --> "0..*" Game : classifica
    Cliente "1" --> "0..*" Pedido : realiza
    Pedido "1" *-- "1..*" ItemPedido : contém
    Game "1" --> "0..*" ItemPedido : é vendido em
    Carrinho ..> Game : usa
    Usuario ..> Pedido : gerencia
```

## 5. Modelo do banco de dados (MER)
```mermaid
erDiagram
    USUARIOS   { int id PK  string email UK  string senha  enum papel  bool ativo }
    CLIENTES   { int id PK  string email UK  string telefone  string senha  bool ativo }
    CATEGORIAS { int id PK  string nome UK  string descricao }
    GAMES      { int id PK  int categoria_id FK  string titulo  decimal preco  int estoque  string imagem  bool destaque  bool ativo }
    PEDIDOS    { int id PK  int cliente_id FK  enum status  enum forma_pagamento  decimal total }
    ITENS_PEDIDO { int id PK  int pedido_id FK  int game_id FK  int quantidade  decimal preco_unitario }

    CATEGORIAS ||--o{ GAMES : "possui"
    CLIENTES   ||--o{ PEDIDOS : "realiza"
    PEDIDOS    ||--|{ ITENS_PEDIDO : "contém"
    GAMES      ||--o{ ITENS_PEDIDO : "aparece em"
```
Script completo: [`database/banco.sql`](../database/banco.sql) (criação do banco, tabelas, PKs, FKs, índices, `CHECK` e dados de teste).

## 6. Arquitetura (MVC)
`public/index.php` (front controller) → `Router` → **Controller** → **Model** (PDO) → **View** (dentro de um layout). Detalhes no README.
