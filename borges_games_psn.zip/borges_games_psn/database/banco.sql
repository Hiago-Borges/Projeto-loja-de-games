-- =====================================================================
-- Borges Games — Loja de jogos digitais
-- Script completo: criação do banco, tabelas, chaves e dados de teste.
-- Como usar: phpMyAdmin > aba "SQL" > cole tudo > Executar
--            (ou:  mysql -u root < database/banco.sql)
-- ATENÇÃO: recria o banco do zero (apaga dados anteriores).
-- =====================================================================

DROP DATABASE IF EXISTS borges_games;
CREATE DATABASE borges_games CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE borges_games;

-- ---------------------------------------------------------------------
-- USUARIOS: equipe interna que acessa o painel administrativo
--   papel 'admin'   -> acesso total (inclui gerenciar usuários)
--   papel 'gerente' -> acesso ao painel, exceto usuários
-- ---------------------------------------------------------------------
CREATE TABLE usuarios (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome       VARCHAR(120) NOT NULL,
    email      VARCHAR(160) NOT NULL,
    senha      VARCHAR(255) NOT NULL,              -- password_hash()
    papel      ENUM('admin','gerente') NOT NULL DEFAULT 'gerente',
    ativo      TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT uq_usuarios_email UNIQUE (email)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- CLIENTES: compradores da loja (cadastro pelo site)
-- ---------------------------------------------------------------------
CREATE TABLE clientes (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome       VARCHAR(120) NOT NULL,
    email      VARCHAR(160) NOT NULL,
    telefone   VARCHAR(20)  NOT NULL,
    senha      VARCHAR(255) NOT NULL,              -- password_hash()
    ativo      TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT uq_clientes_email UNIQUE (email)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- CATEGORIAS dos jogos
-- ---------------------------------------------------------------------
CREATE TABLE categorias (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome       VARCHAR(80)  NOT NULL,
    descricao  VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT uq_categorias_nome UNIQUE (nome)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- GAMES (produtos)
-- ---------------------------------------------------------------------
CREATE TABLE games (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    categoria_id INT UNSIGNED NOT NULL,
    titulo       VARCHAR(160) NOT NULL,
    descricao    TEXT NOT NULL,
    preco        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    estoque      INT UNSIGNED NOT NULL DEFAULT 0,
    imagem       VARCHAR(255) NULL,
    destaque     TINYINT(1) NOT NULL DEFAULT 0,    -- aparece no banner da home
    ativo        TINYINT(1) NOT NULL DEFAULT 1,    -- 0 = oculto na loja
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_games_preco CHECK (preco >= 0),
    CONSTRAINT fk_games_categoria FOREIGN KEY (categoria_id)
        REFERENCES categorias (id) ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_games_titulo (titulo),
    INDEX idx_games_categoria (categoria_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- PEDIDOS e ITENS_PEDIDO  (relação 1:N, e N:N entre pedidos e games)
-- ---------------------------------------------------------------------
CREATE TABLE pedidos (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    cliente_id      INT UNSIGNED NOT NULL,
    status          ENUM('pendente','pago','cancelado') NOT NULL DEFAULT 'pendente',
    forma_pagamento ENUM('pix','cartao','boleto') NOT NULL DEFAULT 'pix',
    total           DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_pedidos_cliente FOREIGN KEY (cliente_id)
        REFERENCES clientes (id) ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_pedidos_status (status),
    INDEX idx_pedidos_data (created_at)
) ENGINE=InnoDB;

CREATE TABLE itens_pedido (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pedido_id      INT UNSIGNED NOT NULL,
    game_id        INT UNSIGNED NOT NULL,
    quantidade     INT UNSIGNED NOT NULL DEFAULT 1,
    preco_unitario DECIMAL(10,2) NOT NULL,         -- preço no momento da compra
    CONSTRAINT chk_itens_qtd CHECK (quantidade > 0),
    CONSTRAINT fk_itens_pedido FOREIGN KEY (pedido_id)
        REFERENCES pedidos (id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_itens_game FOREIGN KEY (game_id)
        REFERENCES games (id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT uq_item_pedido_game UNIQUE (pedido_id, game_id)
) ENGINE=InnoDB;

-- =====================================================================
-- DADOS INICIAIS PARA TESTE
-- Logins:  admin@borges.games / admin123      (administrador)
--          gerente@borges.games / admin123    (gerente)
--          ana@email.com / cliente123         (cliente)
-- =====================================================================
INSERT INTO usuarios (nome, email, senha, papel) VALUES
('Administrador Borges', 'admin@borges.games',   '$2y$10$9g6kZ1ePj5V82e75tNgyTOISq.KY2ruT7s7z/gzbtb9Q4dzc9oH92', 'admin'),
('Gerente da Loja',      'gerente@borges.games', '$2y$10$9g6kZ1ePj5V82e75tNgyTOISq.KY2ruT7s7z/gzbtb9Q4dzc9oH92', 'gerente');

INSERT INTO clientes (nome, email, telefone, senha) VALUES
('Ana Souza',    'ana@email.com',    '38991234567', '$2y$10$QCa/GYx/1mHXicEAdBew5OR75jDBb6uIw3OKssZvzL1eBH.AEqQyG'),
('Bruno Lima',   'bruno@email.com',  '38998765432', '$2y$10$QCa/GYx/1mHXicEAdBew5OR75jDBb6uIw3OKssZvzL1eBH.AEqQyG'),
('Carla Mendes', 'carla@email.com',  '3832215566',  '$2y$10$QCa/GYx/1mHXicEAdBew5OR75jDBb6uIw3OKssZvzL1eBH.AEqQyG');

INSERT INTO categorias (nome, descricao) VALUES
('RPG',        'Role-playing games: histórias profundas e evolução de personagem.'),
('Ação',       'Combate intenso e muita adrenalina.'),
('Aventura',   'Exploração, descobertas e mundos abertos.'),
('Corrida',    'Velocidade, carros e pistas de tirar o fôlego.'),
('Estratégia', 'Planejamento, gestão e decisões táticas.');

-- As imagens ficam em public/uploads/
INSERT INTO games (categoria_id, titulo, descricao, preco, estoque, imagem, destaque) VALUES
(1, 'Baldur''s Gate 3',  'RPG épico de fantasia com escolhas que mudam toda a história.',          199.90, 12, 'BaldursGate.jpg', 1),
(2, 'God of War',        'Kratos e Atreus numa jornada brutal pela mitologia nórdica.',             149.90,  8, 'gow.jpg',         1),
(3, 'Minecraft',         'Construa, explore e sobreviva em mundos infinitos.',                       99.90, 30, 'minecraft.jpg',   1),
(3, 'Roblox',            'Milhares de jogos criados pela comunidade para jogar com amigos.',         49.90,  3, 'Roblox.jpg',      0),
(3, 'Zelda',             'Explore Hyrule e enfrente o mal em uma aventura lendária.',               249.90,  0, 'zeldinha.jpg',    0),
(1, 'Elden Ring',        'Um vasto mundo de fantasia sombria criado por FromSoftware e G. R. R. Martin.', 229.90, 15, NULL,       0),
(4, 'Forza Horizon 5',   'Corra por paisagens mexicanas deslumbrantes em um mundo aberto.',         179.90, 10, NULL,              0),
(5, 'Civilization VI',   'Construa um império que resista ao teste do tempo.',                      119.90,  7, NULL,              0);

-- Pedidos de exemplo (alimentam o dashboard e o relatório de vendas)
INSERT INTO pedidos (id, cliente_id, status, forma_pagamento, total, created_at) VALUES
(1, 1, 'pago',      'pix',    299.80, DATE_SUB(NOW(), INTERVAL 18 DAY)),
(2, 2, 'pago',      'cartao', 249.70, DATE_SUB(NOW(), INTERVAL 14 DAY)),
(3, 1, 'pendente',  'boleto', 229.90, DATE_SUB(NOW(), INTERVAL 5 DAY)),
(4, 3, 'cancelado', 'pix',    249.90, DATE_SUB(NOW(), INTERVAL 9 DAY)),
(5, 2, 'pago',      'pix',    299.80, DATE_SUB(NOW(), INTERVAL 3 DAY)),
(6, 3, 'pago',      'cartao', 199.80, DATE_SUB(NOW(), INTERVAL 1 DAY));

INSERT INTO itens_pedido (pedido_id, game_id, quantidade, preco_unitario) VALUES
(1, 1, 1, 199.90), (1, 3, 1,  99.90),
(2, 2, 1, 149.90), (2, 4, 2,  49.90),
(3, 6, 1, 229.90),
(4, 5, 1, 249.90),
(5, 8, 1, 119.90), (5, 7, 1, 179.90),
(6, 3, 2,  99.90);
