<?php
/** @var App\Core\Router $router */

use App\Controllers\{AuthController, CarrinhoController, ContaController, HomeController, JogoController};
use App\Controllers\Admin\{CategoriaController, ClienteController, DashboardController, GameController,
                           PedidoController, RelatorioController, UsuarioController};

// ---------------------------------------------------------------- PÚBLICO
$router->get('/',             [HomeController::class, 'index']);
$router->get('/jogo/{id}',    [JogoController::class, 'ver']);

// Carrinho
$router->get ('/carrinho',            [CarrinhoController::class, 'index']);
$router->post('/carrinho/adicionar',  [CarrinhoController::class, 'adicionar']);
$router->post('/carrinho/atualizar',  [CarrinhoController::class, 'atualizar']);
$router->post('/carrinho/remover',    [CarrinhoController::class, 'remover']);
$router->post('/carrinho/finalizar',  [CarrinhoController::class, 'finalizar'], ['cliente']);

// Autenticação e registro de cliente
$router->get ('/login',    [AuthController::class, 'loginForm'],    ['guest']);
$router->post('/login',    [AuthController::class, 'login'],        ['guest']);
$router->get ('/cadastro', [AuthController::class, 'registroForm'], ['guest']);
$router->post('/cadastro', [AuthController::class, 'registrar'],    ['guest']);
$router->post('/logout',   [AuthController::class, 'logout']);

// ---------------------------------------------------------------- ÁREA LOGADA
$router->get ('/conta',               [ContaController::class, 'index'],           ['auth']);
$router->post('/conta/dados',         [ContaController::class, 'atualizarDados'],  ['auth']);
$router->post('/conta/senha',         [ContaController::class, 'atualizarSenha'],  ['auth']);
$router->get ('/conta/pedidos',       [ContaController::class, 'pedidos'],         ['cliente']);
$router->get ('/conta/pedidos/{id}',  [ContaController::class, 'pedido'],          ['cliente']);

// ---------------------------------------------------------------- ADMIN
$adm = ['admin'];
$router->get('/admin',            [DashboardController::class, 'index'], $adm);
$router->get('/admin/relatorios', [RelatorioController::class, 'vendas'], $adm);

/** Registra as 6 rotas padrão de um CRUD:  listar, novo, salvar, editar, atualizar, excluir. */
$crud = function (string $prefixo, string $controller, array $mw) use ($router): void {
    $router->get ("/admin/$prefixo",                [$controller, 'index'],     $mw);
    $router->get ("/admin/$prefixo/novo",           [$controller, 'criar'],     $mw);
    $router->post("/admin/$prefixo",                [$controller, 'salvar'],    $mw);
    $router->get ("/admin/$prefixo/{id}/editar",    [$controller, 'editar'],    $mw);
    $router->post("/admin/$prefixo/{id}",           [$controller, 'atualizar'], $mw);
    $router->post("/admin/$prefixo/{id}/excluir",   [$controller, 'excluir'],   $mw);
};

$crud('games',      GameController::class,      $adm);
$crud('categorias', CategoriaController::class, $adm);
$crud('clientes',   ClienteController::class,   $adm);
$crud('usuarios',   UsuarioController::class,   ['superadmin']);
$crud('pedidos',    PedidoController::class,    $adm);

// Pedidos: detalhes (leitura) — registrado depois do CRUD; {id} só casa com números.
$router->get('/admin/pedidos/{id}', [PedidoController::class, 'ver'], $adm);
