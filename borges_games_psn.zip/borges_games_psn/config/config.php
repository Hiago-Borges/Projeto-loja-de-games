<?php
// Configurações gerais. Altere conforme o seu ambiente (XAMPP/WAMP/Laragon).
return [
    'db' => [
        'host'    => 'localhost',
        'port'    => 3306,
        'name'    => 'borges_games',
        'user'    => 'root',
        'pass'    => '',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'nome'         => 'Borges Games',
        'debug'        => true,          // false em produção
        'upload_max'   => 2 * 1024 * 1024, // 2 MB
        'por_pagina'   => 10,            // paginação do admin
    ],
];
