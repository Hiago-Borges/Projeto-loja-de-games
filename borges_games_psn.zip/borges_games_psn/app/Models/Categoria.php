<?php
namespace App\Models;

use App\Core\Model;

class Categoria extends Model
{
    protected string $tabela = 'categorias';

    public function listar(string $busca = '', int $pagina = 1, int $porPagina = 10): array
    {
        $where  = '1=1';
        $params = [];
        if ($busca !== '') {
            $where .= ' AND (c.nome LIKE :b1 OR c.descricao LIKE :b2)';
            $params = ['b1' => "%$busca%", 'b2' => "%$busca%"];
        }
        return $this->paginar(
            "SELECT c.*, (SELECT COUNT(*) FROM games g WHERE g.categoria_id = c.id) AS total_games
               FROM categorias c WHERE $where ORDER BY c.nome ASC",
            "SELECT COUNT(*) FROM categorias c WHERE $where",
            $params, $pagina, $porPagina
        );
    }

    /** Todas, para menus e <select>. */
    public function todas(): array
    {
        return $this->todos('SELECT * FROM categorias ORDER BY nome ASC');
    }

    /** Somente categorias que têm jogos ativos (menu da loja). */
    public function comJogosAtivos(): array
    {
        return $this->todos(
            'SELECT c.* FROM categorias c
              WHERE EXISTS (SELECT 1 FROM games g WHERE g.categoria_id = c.id AND g.ativo = 1)
              ORDER BY c.nome ASC'
        );
    }

    public function nomeEmUso(string $nome, int $ignorarId = 0): bool
    {
        return (int)$this->valor('SELECT COUNT(*) FROM categorias WHERE nome = :n AND id <> :i',
            ['n' => $nome, 'i' => $ignorarId]) > 0;
    }

    public function criar(array $d): int
    {
        $this->executar('INSERT INTO categorias (nome, descricao) VALUES (:n, :d)',
            ['n' => $d['nome'], 'd' => $d['descricao'] !== '' ? $d['descricao'] : null]);
        return (int)$this->pdo->lastInsertId();
    }

    public function atualizar(int $id, array $d): bool
    {
        $this->executar('UPDATE categorias SET nome = :n, descricao = :d WHERE id = :id',
            ['id' => $id, 'n' => $d['nome'], 'd' => $d['descricao'] !== '' ? $d['descricao'] : null]);
        return true;
    }
}
