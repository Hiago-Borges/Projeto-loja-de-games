<?php
namespace App\Models;

use App\Core\Model;

class Game extends Model
{
    protected string $tabela = 'games';

    private const SELECT = 'SELECT g.*, c.nome AS categoria FROM games g JOIN categorias c ON c.id = g.categoria_id';

    private const ORDENS = [
        'recentes'   => 'g.created_at DESC, g.id DESC',
        'nome'       => 'g.titulo ASC',
        'menor'      => 'g.preco ASC',
        'maior'      => 'g.preco DESC',
    ];

    // ------------------------------------------------------------ LOJA (público)

    /** Catálogo público: somente jogos ativos, com busca por nome e filtro por categoria. */
    public function listarPublico(string $busca = '', int $categoriaId = 0, string $ordem = 'recentes'): array
    {
        $where  = 'g.ativo = 1';
        $params = [];
        if ($busca !== '') {
            $where .= ' AND (g.titulo LIKE :b1 OR g.descricao LIKE :b2)';
            $params['b1'] = "%$busca%";
            $params['b2'] = "%$busca%";
        }
        if ($categoriaId > 0) {
            $where .= ' AND g.categoria_id = :cat';
            $params['cat'] = $categoriaId;
        }
        $ord = self::ORDENS[$ordem] ?? self::ORDENS['recentes'];
        return $this->todos(self::SELECT . " WHERE $where ORDER BY $ord", $params);
    }

    /** Jogos marcados como destaque (banner), com imagem e em estoque. */
    public function destaques(int $limite = 4): array
    {
        return $this->todos(
            self::SELECT . ' WHERE g.ativo = 1 AND g.destaque = 1 AND g.estoque > 0 AND g.imagem IS NOT NULL
                             ORDER BY g.preco DESC LIMIT :l',
            ['l' => $limite]
        );
    }

    public function buscarCompleto(int $id): ?array
    {
        return $this->um(self::SELECT . ' WHERE g.id = :id', ['id' => $id]);
    }

    public function buscarVarios(array $ids): array
    {
        $ids = array_values(array_map('intval', $ids));
        if (!$ids) return [];
        $in = implode(',', array_fill(0, count($ids), '?'));
        return $this->todos(self::SELECT . " WHERE g.id IN ($in)", $ids);
    }

    /** Outros jogos da mesma categoria (página de detalhes). */
    public function relacionados(int $categoriaId, int $excetoId, int $limite = 4): array
    {
        return $this->todos(
            self::SELECT . ' WHERE g.ativo = 1 AND g.categoria_id = :c AND g.id <> :i ORDER BY g.created_at DESC LIMIT :l',
            ['c' => $categoriaId, 'i' => $excetoId, 'l' => $limite]
        );
    }

    // ------------------------------------------------------------ ADMIN

    public function listarAdmin(string $busca = '', int $categoriaId = 0, int $pagina = 1, int $porPagina = 10): array
    {
        $where  = '1=1';
        $params = [];
        if ($busca !== '') {
            $where .= ' AND (g.titulo LIKE :b1 OR g.descricao LIKE :b2)';
            $params['b1'] = "%$busca%";
            $params['b2'] = "%$busca%";
        }
        if ($categoriaId > 0) {
            $where .= ' AND g.categoria_id = :cat';
            $params['cat'] = $categoriaId;
        }
        return $this->paginar(
            self::SELECT . " WHERE $where ORDER BY g.titulo ASC",
            "SELECT COUNT(*) FROM games g WHERE $where",
            $params, $pagina, $porPagina
        );
    }

    /** Lista simples de jogos ativos (formulário de pedido manual). */
    public function todosAtivos(): array
    {
        return $this->todos('SELECT id, titulo, preco, estoque FROM games WHERE ativo = 1 ORDER BY titulo');
    }

    public function criar(array $d): int
    {
        $this->executar(
            'INSERT INTO games (categoria_id, titulo, descricao, preco, estoque, imagem, destaque, ativo)
             VALUES (:cat, :titulo, :descricao, :preco, :estoque, :imagem, :destaque, :ativo)',
            $this->params($d)
        );
        return (int)$this->pdo->lastInsertId();
    }

    public function atualizar(int $id, array $d): bool
    {
        $this->executar(
            'UPDATE games SET categoria_id = :cat, titulo = :titulo, descricao = :descricao, preco = :preco,
                    estoque = :estoque, imagem = :imagem, destaque = :destaque, ativo = :ativo
              WHERE id = :id',
            $this->params($d) + ['id' => $id]
        );
        return true;
    }

    private function params(array $d): array
    {
        return [
            'cat'       => (int)$d['categoria_id'],
            'titulo'    => $d['titulo'],
            'descricao' => $d['descricao'],
            'preco'     => number_format((float)str_replace(',', '.', (string)$d['preco']), 2, '.', ''),
            'estoque'   => (int)$d['estoque'],
            'imagem'    => $d['imagem'] ?: null,
            'destaque'  => (int)($d['destaque'] ?? 0),
            'ativo'     => (int)($d['ativo'] ?? 1),
        ];
    }

    // ------------------------------------------------------------ ESTOQUE / DASHBOARD

    public function estoqueBaixo(int $limite = 5, int $ate = 5): array
    {
        return $this->todos(
            self::SELECT . ' WHERE g.ativo = 1 AND g.estoque <= :ate ORDER BY g.estoque ASC, g.titulo LIMIT :l',
            ['ate' => $ate, 'l' => $limite]
        );
    }

    /** [jogos, unidades em estoque, valor total em estoque] */
    public function resumoEstoque(): array
    {
        return $this->um('SELECT COUNT(*) AS jogos, COALESCE(SUM(estoque),0) AS unidades,
                                 COALESCE(SUM(estoque * preco),0) AS valor FROM games');
    }
}
