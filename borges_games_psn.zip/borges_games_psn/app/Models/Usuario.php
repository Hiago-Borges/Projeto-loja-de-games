<?php
namespace App\Models;

use App\Core\Model;

/** Equipe interna (painel administrativo). */
class Usuario extends Model
{
    protected string $tabela = 'usuarios';

    public const PAPEIS = ['admin', 'gerente'];

    public function listar(string $busca = '', int $pagina = 1, int $porPagina = 10): array
    {
        $where  = '1=1';
        $params = [];
        if ($busca !== '') {
            $where .= ' AND (nome LIKE :b1 OR email LIKE :b2)';
            $params = ['b1' => "%$busca%", 'b2' => "%$busca%"];
        }
        return $this->paginar(
            "SELECT id, nome, email, papel, ativo, created_at, updated_at FROM usuarios WHERE $where ORDER BY nome ASC",
            "SELECT COUNT(*) FROM usuarios WHERE $where",
            $params, $pagina, $porPagina
        );
    }

    public function buscarPorEmail(string $email): ?array
    {
        return $this->um('SELECT * FROM usuarios WHERE email = :e', ['e' => strtolower($email)]);
    }

    /** E-mail já usado por outro usuário OU por qualquer cliente (login único no sistema). */
    public function emailEmUso(string $email, int $ignorarId = 0): bool
    {
        return (int)$this->valor(
            "SELECT (SELECT COUNT(*) FROM usuarios WHERE email = :e1 AND id <> :i)
                  + (SELECT COUNT(*) FROM clientes WHERE email = :e2)",
            ['e1' => strtolower($email), 'i' => $ignorarId, 'e2' => strtolower($email)]
        ) > 0;
    }

    public function criar(array $d): int
    {
        $this->executar(
            'INSERT INTO usuarios (nome, email, senha, papel, ativo) VALUES (:nome, :email, :senha, :papel, :ativo)',
            [
                'nome'  => $d['nome'],
                'email' => strtolower($d['email']),
                'senha' => password_hash($d['senha'], PASSWORD_DEFAULT),
                'papel' => $d['papel'],
                'ativo' => (int)($d['ativo'] ?? 1),
            ]
        );
        return (int)$this->pdo->lastInsertId();
    }

    public function atualizar(int $id, array $d): bool
    {
        $this->executar(
            'UPDATE usuarios SET nome = :nome, email = :email, papel = :papel, ativo = :ativo WHERE id = :id',
            [
                'id'    => $id,
                'nome'  => $d['nome'],
                'email' => strtolower($d['email']),
                'papel' => $d['papel'],
                'ativo' => (int)($d['ativo'] ?? 1),
            ]
        );
        return true;
    }

    public function atualizarPerfil(int $id, string $nome, string $email): void
    {
        $this->executar('UPDATE usuarios SET nome = :n, email = :e WHERE id = :id',
            ['n' => $nome, 'e' => strtolower($email), 'id' => $id]);
    }

    public function alterarSenha(int $id, string $novaSenha): void
    {
        $this->executar('UPDATE usuarios SET senha = :s WHERE id = :id',
            ['s' => password_hash($novaSenha, PASSWORD_DEFAULT), 'id' => $id]);
    }

    /** Valida e-mail + senha. Retorna o usuário (com 'papel') ou null. */
    public function autenticar(string $email, string $senha): ?array
    {
        $u = $this->buscarPorEmail($email);
        if (!$u || !$u['ativo'] || !password_verify($senha, $u['senha'])) return null;

        if (password_needs_rehash($u['senha'], PASSWORD_DEFAULT)) $this->alterarSenha((int)$u['id'], $senha);
        return $u;
    }

    public function contarAdminsAtivos(): int
    {
        return (int)$this->valor("SELECT COUNT(*) FROM usuarios WHERE papel = 'admin' AND ativo = 1");
    }
}
