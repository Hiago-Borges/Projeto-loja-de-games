<?php
namespace App\Models;

use App\Core\Model;

class Pedido extends Model
{
    protected string $tabela = 'pedidos';

    public const STATUS     = ['pendente', 'pago', 'cancelado'];
    public const PAGAMENTOS = ['pix', 'cartao', 'boleto'];

    // ------------------------------------------------------------ CONSULTAS

    public function listar(string $busca = '', string $status = '', int $pagina = 1, int $porPagina = 10): array
    {
        $where  = '1=1';
        $params = [];
        if ($busca !== '') {
            $where .= ' AND (c.nome LIKE :b1 OR c.email LIKE :b2' . (ctype_digit($busca) ? ' OR p.id = :bid' : '') . ')';
            $params['b1'] = "%$busca%";
            $params['b2'] = "%$busca%";
            if (ctype_digit($busca)) $params['bid'] = (int)$busca;
        }
        if (in_array($status, self::STATUS, true)) {
            $where .= ' AND p.status = :st';
            $params['st'] = $status;
        }
        return $this->paginar(
            "SELECT p.*, c.nome AS cliente_nome, c.email AS cliente_email,
                    (SELECT COALESCE(SUM(quantidade),0) FROM itens_pedido WHERE pedido_id = p.id) AS qtd_itens
               FROM pedidos p JOIN clientes c ON c.id = p.cliente_id
              WHERE $where ORDER BY p.created_at DESC, p.id DESC",
            "SELECT COUNT(*) FROM pedidos p JOIN clientes c ON c.id = p.cliente_id WHERE $where",
            $params, $pagina, $porPagina
        );
    }

    public function buscarCompleto(int $id): ?array
    {
        return $this->um(
            'SELECT p.*, c.nome AS cliente_nome, c.email AS cliente_email, c.telefone AS cliente_telefone
               FROM pedidos p JOIN clientes c ON c.id = p.cliente_id WHERE p.id = :id',
            ['id' => $id]
        );
    }

    public function itens(int $pedidoId): array
    {
        return $this->todos(
            'SELECT i.*, g.titulo, g.imagem, (i.quantidade * i.preco_unitario) AS subtotal
               FROM itens_pedido i JOIN games g ON g.id = i.game_id
              WHERE i.pedido_id = :id ORDER BY g.titulo',
            ['id' => $pedidoId]
        );
    }

    public function listarDoCliente(int $clienteId): array
    {
        return $this->todos(
            'SELECT p.*, (SELECT COALESCE(SUM(quantidade),0) FROM itens_pedido WHERE pedido_id = p.id) AS qtd_itens
               FROM pedidos p WHERE p.cliente_id = :c ORDER BY p.created_at DESC, p.id DESC',
            ['c' => $clienteId]
        );
    }

    public function recentes(int $limite = 6): array
    {
        return $this->todos(
            'SELECT p.*, c.nome AS cliente_nome FROM pedidos p JOIN clientes c ON c.id = p.cliente_id
              ORDER BY p.created_at DESC, p.id DESC LIMIT :l',
            ['l' => $limite]
        );
    }

    // ------------------------------------------------------------ ESCRITA (com transação)

    /**
     * Cria o pedido, grava os itens (com o preço do momento) e baixa o estoque.
     * Tudo em uma transação: ou grava tudo, ou nada.
     * @param array $linhas  [['game_id' => 1, 'qtd' => 2], ...]
     * @throws \RuntimeException|\InvalidArgumentException com mensagem amigável
     */
    public function criar(int $clienteId, array $linhas, string $pagamento, string $status = 'pendente'): int
    {
        if (!in_array($pagamento, self::PAGAMENTOS, true)) throw new \InvalidArgumentException('Forma de pagamento inválida.');
        if (!in_array($status, ['pendente', 'pago'], true)) throw new \InvalidArgumentException('Status inicial inválido.');

        $qtds = [];
        foreach ($linhas as $l) {
            $gid = (int)($l['game_id'] ?? 0);
            $q   = (int)($l['qtd'] ?? 0);
            if ($gid > 0 && $q > 0) $qtds[$gid] = ($qtds[$gid] ?? 0) + $q;
        }
        if (!$qtds) throw new \InvalidArgumentException('Adicione ao menos um jogo ao pedido.');
        ksort($qtds); // ordem fixa evita deadlock entre pedidos simultâneos

        $this->pdo->beginTransaction();
        try {
            $itens = [];
            $total = 0.0;
            foreach ($qtds as $gid => $q) {
                $g = $this->um('SELECT id, titulo, preco, estoque, ativo FROM games WHERE id = :id FOR UPDATE', ['id' => $gid]);
                if (!$g || !$g['ativo']) throw new \RuntimeException('Um dos jogos não está mais disponível.');
                if ((int)$g['estoque'] < $q) {
                    throw new \RuntimeException("Estoque insuficiente para \"{$g['titulo']}\" (disponível: {$g['estoque']}).");
                }
                $itens[] = ['game_id' => $gid, 'qtd' => $q, 'preco' => $g['preco']];
                $total  += $q * (float)$g['preco'];
            }

            $this->executar('INSERT INTO pedidos (cliente_id, status, forma_pagamento, total) VALUES (:c, :s, :f, :t)',
                ['c' => $clienteId, 's' => $status, 'f' => $pagamento, 't' => number_format($total, 2, '.', '')]);
            $pedidoId = (int)$this->pdo->lastInsertId();

            foreach ($itens as $i) {
                $this->executar('INSERT INTO itens_pedido (pedido_id, game_id, quantidade, preco_unitario) VALUES (:p, :g, :q, :v)',
                    ['p' => $pedidoId, 'g' => $i['game_id'], 'q' => $i['qtd'], 'v' => $i['preco']]);
                $this->executar('UPDATE games SET estoque = estoque - :q WHERE id = :g', ['q' => $i['qtd'], 'g' => $i['game_id']]);
            }

            $this->pdo->commit();
            return $pedidoId;
        } catch (\Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    /** Altera status/pagamento. Cancelar devolve o estoque; pedido cancelado não pode ser reaberto. */
    public function atualizar(int $id, string $status, string $pagamento): void
    {
        if (!in_array($status, self::STATUS, true)) throw new \InvalidArgumentException('Status inválido.');
        if (!in_array($pagamento, self::PAGAMENTOS, true)) throw new \InvalidArgumentException('Forma de pagamento inválida.');

        $this->pdo->beginTransaction();
        try {
            $p = $this->um('SELECT id, status FROM pedidos WHERE id = :id FOR UPDATE', ['id' => $id]);
            if (!$p) throw new \RuntimeException('Pedido não encontrado.');
            if ($p['status'] === 'cancelado' && $status !== 'cancelado') {
                throw new \RuntimeException('Um pedido cancelado não pode ser reaberto. Crie um novo pedido.');
            }
            if ($status === 'cancelado' && $p['status'] !== 'cancelado') $this->devolverEstoque($id);

            $this->executar('UPDATE pedidos SET status = :s, forma_pagamento = :f WHERE id = :id',
                ['s' => $status, 'f' => $pagamento, 'id' => $id]);
            $this->pdo->commit();
        } catch (\Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    /** Exclui o pedido; se ainda estava ativo, devolve o estoque antes. */
    public function excluir(int $id): bool
    {
        $this->pdo->beginTransaction();
        try {
            $p = $this->um('SELECT id, status FROM pedidos WHERE id = :id FOR UPDATE', ['id' => $id]);
            if (!$p) { $this->pdo->rollBack(); return false; }
            if ($p['status'] !== 'cancelado') $this->devolverEstoque($id);
            $this->executar('DELETE FROM pedidos WHERE id = :id', ['id' => $id]); // itens saem em cascata
            $this->pdo->commit();
            return true;
        } catch (\Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    private function devolverEstoque(int $pedidoId): void
    {
        $this->executar(
            'UPDATE games g JOIN itens_pedido i ON i.game_id = g.id
                SET g.estoque = g.estoque + i.quantidade WHERE i.pedido_id = :id',
            ['id' => $pedidoId]
        );
    }

    // ------------------------------------------------------------ RELATÓRIOS (somente pedidos PAGOS)

    private function periodo(string $ini, string $fim): array
    {
        return ['ini' => $ini . ' 00:00:00', 'fim' => $fim . ' 23:59:59'];
    }

    /** [pedidos, receita, ticket médio] no período. */
    public function resumo(string $ini, string $fim): array
    {
        $r = $this->um(
            "SELECT COUNT(*) AS pedidos, COALESCE(SUM(total),0) AS receita, COALESCE(AVG(total),0) AS ticket
               FROM pedidos WHERE status = 'pago' AND created_at BETWEEN :ini AND :fim",
            $this->periodo($ini, $fim)
        );
        $r['itens'] = (int)$this->valor(
            "SELECT COALESCE(SUM(i.quantidade),0) FROM itens_pedido i JOIN pedidos p ON p.id = i.pedido_id
              WHERE p.status = 'pago' AND p.created_at BETWEEN :ini AND :fim",
            $this->periodo($ini, $fim)
        );
        return $r;
    }

    public function vendasPorDia(string $ini, string $fim): array
    {
        return $this->todos(
            "SELECT DATE(created_at) AS dia, COUNT(*) AS pedidos, SUM(total) AS receita
               FROM pedidos WHERE status = 'pago' AND created_at BETWEEN :ini AND :fim
              GROUP BY DATE(created_at) ORDER BY dia",
            $this->periodo($ini, $fim)
        );
    }

    public function maisVendidos(string $ini, string $fim, int $limite = 5): array
    {
        return $this->todos(
            "SELECT g.id, g.titulo, SUM(i.quantidade) AS qtd, SUM(i.quantidade * i.preco_unitario) AS receita
               FROM itens_pedido i
               JOIN pedidos p ON p.id = i.pedido_id AND p.status = 'pago' AND p.created_at BETWEEN :ini AND :fim
               JOIN games g ON g.id = i.game_id
              GROUP BY g.id, g.titulo ORDER BY qtd DESC, receita DESC LIMIT :l",
            $this->periodo($ini, $fim) + ['l' => $limite]
        );
    }

    public function vendasPorCategoria(string $ini, string $fim): array
    {
        return $this->todos(
            "SELECT c.nome, SUM(i.quantidade) AS qtd, SUM(i.quantidade * i.preco_unitario) AS receita
               FROM itens_pedido i
               JOIN pedidos p ON p.id = i.pedido_id AND p.status = 'pago' AND p.created_at BETWEEN :ini AND :fim
               JOIN games g ON g.id = i.game_id
               JOIN categorias c ON c.id = g.categoria_id
              GROUP BY c.id, c.nome ORDER BY receita DESC",
            $this->periodo($ini, $fim)
        );
    }

    public function vendasPorPagamento(string $ini, string $fim): array
    {
        return $this->todos(
            "SELECT forma_pagamento, COUNT(*) AS pedidos, SUM(total) AS receita
               FROM pedidos WHERE status = 'pago' AND created_at BETWEEN :ini AND :fim
              GROUP BY forma_pagamento ORDER BY receita DESC",
            $this->periodo($ini, $fim)
        );
    }

    public function contarPorStatus(): array
    {
        $r = array_fill_keys(self::STATUS, 0);
        foreach ($this->todos('SELECT status, COUNT(*) AS n FROM pedidos GROUP BY status') as $l) $r[$l['status']] = (int)$l['n'];
        return $r;
    }
}
