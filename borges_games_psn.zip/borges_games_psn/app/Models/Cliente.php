<?php
namespace App\Models;

use App\Core\Model;

/** Compradores da loja. */
class Cliente extends Model
{
    protected string $tabela = 'clientes';

    public function listar(string $busca = '', int $pagina = 1, int $porPagina = 10): array
    {
        $where  = '1=1';
        $params = [];
        if ($busca !== '') {
            $where .= ' AND (c.nome LIKE :b1 OR c.email LIKE :b2 OR c.telefone LIKE :b3)';
            $params = ['b1' => "%$busca%", 'b2' => "%$busca%", 'b3' => "%$busca%"];
        }
        return $this->paginar(
            "SELECT c.id, c.nome, c.email, c.telefone, c.ativo, c.created_at,
                    (SELECT COUNT(*) FROM pedidos p WHERE p.cliente_id = c.id) AS total_pedidos
               FROM clientes c WHERE $where ORDER BY c.nome ASC",
            "SELECT COUNT(*) FROM clientes c WHERE $where",
            $params, $pagina, $porPagina
        );
    }

    /** Lista simples para <select>. */
    public function todosAtivos(): array
    {
        return $this->todos('SELECT id, nome, email FROM clientes WHERE ativo = 1 ORDER BY nome');
    }

    public function buscarPorEmail(string $email): ?array
    {
        return $this->um('SELECT * FROM clientes WHERE email = :e', ['e' => strtolower($email)]);
    }

    public function emailEmUso(string $email, int $ignorarId = 0): bool
    {
        return (int)$this->valor(
            "SELECT (SELECT COUNT(*) FROM clientes WHERE email = :e1 AND id <> :i)
                  + (SELECT COUNT(*) FROM usuarios WHERE email = :e2)",
            ['e1' => strtolower($email), 'i' => $ignorarId, 'e2' => strtolower($email)]
        ) > 0;
    }

    public function criar(array $d): int
    {
        $this->executar(
            'INSERT INTO clientes (nome, email, telefone, senha, ativo) VALUES (:nome, :email, :tel, :senha, :ativo)',
            [
                'nome'  => $d['nome'],
                'email' => strtolower($d['email']),
                'tel'   => preg_replace('/\D/', '', $d['telefone']),
                'senha' => password_hash($d['senha'], PASSWORD_DEFAULT),
                'ativo' => (int)($d['ativo'] ?? 1),
            ]
        );
        return (int)$this->pdo->lastInsertId();
    }

    public function atualizar(int $id, array $d): bool
    {
        $this->executar(
            'UPDATE clientes SET nome = :nome, email = :email, telefone = :tel, ativo = :ativo WHERE id = :id',
            [
                'id'    => $id,
                'nome'  => $d['nome'],
                'email' => strtolower($d['email']),
                'tel'   => preg_replace('/\D/', '', $d['telefone']),
                'ativo' => (int)($d['ativo'] ?? 1),
            ]
        );
        return true;
    }

    public function atualizarPerfil(int $id, string $nome, string $email, string $telefone): void
    {
        $this->executar('UPDATE clientes SET nome = :n, email = :e, telefone = :t WHERE id = :id',
            ['n' => $nome, 'e' => strtolower($email), 't' => preg_replace('/\D/', '', $telefone), 'id' => $id]);
    }

    public function alterarSenha(int $id, string $novaSenha): void
    {
        $this->executar('UPDATE clientes SET senha = :s WHERE id = :id',
            ['s' => password_hash($novaSenha, PASSWORD_DEFAULT), 'id' => $id]);
    }

    public function autenticar(string $email, string $senha): ?array
    {
        $c = $this->buscarPorEmail($email);
        if (!$c || !$c['ativo'] || !password_verify($senha, $c['senha'])) return null;

        if (password_needs_rehash($c['senha'], PASSWORD_DEFAULT)) $this->alterarSenha((int)$c['id'], $senha);
        return $c;
    }
}
