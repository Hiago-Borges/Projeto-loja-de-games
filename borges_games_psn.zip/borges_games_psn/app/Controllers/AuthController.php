<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Core\Validator;
use App\Models\Cliente;
use App\Models\Usuario;

/** Login, logout e registro de clientes. */
class AuthController extends Controller
{
    private const MAX_TENTATIVAS = 5;
    private const BLOQUEIO_SEG   = 60;

    public function loginForm(): void
    {
        $this->view('auth/login', ['titulo' => 'Entrar — Borges Games'], 'auth');
    }

    public function login(): void
    {
        // Proteção simples contra força bruta (por sessão).
        $bloqueadoAte = (int)Session::get('bloqueio_ate', 0);
        if ($bloqueadoAte > time()) {
            Session::flash('erro', 'Muitas tentativas. Aguarde ' . ($bloqueadoAte - time()) . ' segundos.');
            redirect('login');
        }

        $email = $this->post('email');
        $senha = $_POST['senha'] ?? '';

        if ($email === '' || $senha === '') {
            $this->voltarComErros(['Preencha e-mail e senha.'], 'login');
        }

        // 1º tenta a equipe (painel), 2º tenta clientes.
        if ($u = (new Usuario())->autenticar($email, $senha)) {
            Session::login($u, 'admin');
            $this->sucessoLogin('admin');
        }
        if ($c = (new Cliente())->autenticar($email, $senha)) {
            Session::login($c, 'cliente');
            $this->sucessoLogin('cliente');
        }

        $tent = (int)Session::get('tentativas', 0) + 1;
        Session::set('tentativas', $tent);
        if ($tent >= self::MAX_TENTATIVAS) {
            Session::set('bloqueio_ate', time() + self::BLOQUEIO_SEG);
            Session::set('tentativas', 0);
        }
        $this->voltarComErros(['E-mail ou senha inválidos.'], 'login');
    }

    private function sucessoLogin(string $tipo): never
    {
        Session::remover('tentativas');
        Session::remover('bloqueio_ate');
        Session::flash('sucesso', 'Bem-vindo(a), ' . Session::usuario()['nome'] . '!');

        $destino = Session::get('url_destino');
        Session::remover('url_destino');

        // Só aceita redirecionar para dentro desta aplicação (evita open redirect).
        if ($tipo === 'cliente' && is_string($destino) && str_starts_with($destino, base_url() . '/') && !str_starts_with($destino, '//')) {
            header('Location: ' . $destino);
            exit;
        }
        redirect($tipo === 'admin' ? 'admin' : '');
    }

    public function logout(): void
    {
        Session::logout();
        Session::iniciar();               // sessão nova só para exibir a mensagem
        Session::flash('sucesso', 'Você saiu da sua conta.');
        redirect('');
    }

    public function registroForm(): void
    {
        $this->view('auth/registro', ['titulo' => 'Criar conta — Borges Games'], 'auth');
    }

    public function registrar(): void
    {
        $dados = [
            'nome'              => $this->post('nome'),
            'email'             => $this->post('email'),
            'telefone'          => $this->post('telefone'),
            'senha'             => $_POST['senha'] ?? '',
            'senha_confirmacao' => $_POST['senha_confirmacao'] ?? '',
        ];

        $erros = Validator::validar($dados, [
            'nome'              => 'required|min:3|max:120',
            'email'             => 'required|email|max:160',
            'telefone'          => 'required|telefone',
            'senha'             => 'required|min:6|max:72',
            'senha_confirmacao' => 'required|same:senha',
        ], ['nome' => 'Nome', 'email' => 'E-mail', 'telefone' => 'Telefone', 'senha' => 'Senha', 'senha_confirmacao' => 'Confirmação de senha']);

        $clientes = new Cliente();
        if (!isset($erros['email']) && $clientes->emailEmUso($dados['email'])) {
            $erros['email'] = 'Este e-mail já está cadastrado.';
        }
        if ($erros) $this->voltarComErros($erros, 'cadastro');

        $id      = $clientes->criar($dados);
        $cliente = $clientes->buscar($id);
        Session::login($cliente, 'cliente');
        Session::flash('sucesso', 'Conta criada com sucesso! Boas compras.');
        redirect('');
    }
}
