<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Session;
use App\Core\Validator;
use App\Models\Cliente;
use App\Models\Pedido;
use App\Models\Usuario;

/** Área logada: perfil (cliente e equipe) e pedidos do cliente. */
class ContaController extends Controller
{
    private function modelo(): Cliente|Usuario
    {
        return Session::ehAdmin() ? new Usuario() : new Cliente();
    }

    private function dadosAtuais(): array
    {
        $d = $this->modelo()->buscar((int)Session::usuario()['id']);
        if (!$d) {                       // conta apagada com sessão aberta
            Session::logout();
            Session::iniciar();
            redirect('login');
        }
        return $d;
    }

    public function index(): void
    {
        $this->view('conta/perfil', [
            'titulo' => 'Minha conta — Borges Games',
            'dados'  => $this->dadosAtuais(),
        ]);
    }

    public function atualizarDados(): void
    {
        $atual   = $this->dadosAtuais();
        $ehAdmin = Session::ehAdmin();
        $dados   = ['nome' => $this->post('nome'), 'email' => $this->post('email'), 'telefone' => $this->post('telefone')];

        $regras = ['nome' => 'required|min:3|max:120', 'email' => 'required|email|max:160'];
        if (!$ehAdmin) $regras['telefone'] = 'required|telefone';
        $erros = Validator::validar($dados, $regras, ['nome' => 'Nome', 'email' => 'E-mail', 'telefone' => 'Telefone']);

        $modelo = $this->modelo();
        if (!isset($erros['email']) && $modelo->emailEmUso($dados['email'], (int)$atual['id'])) {
            $erros['email'] = 'Este e-mail já está em uso.';
        }
        if ($erros) $this->voltarComErros($erros, 'conta');

        if ($ehAdmin) $modelo->atualizarPerfil((int)$atual['id'], $dados['nome'], $dados['email']);
        else          $modelo->atualizarPerfil((int)$atual['id'], $dados['nome'], $dados['email'], $dados['telefone']);

        $auth = Session::usuario();
        $auth['nome']  = $dados['nome'];
        $auth['email'] = strtolower($dados['email']);
        Session::set('auth', $auth);

        Session::flash('sucesso', 'Dados atualizados com sucesso.');
        redirect('conta');
    }

    public function atualizarSenha(): void
    {
        $atual = $this->dadosAtuais();
        $velha = $_POST['senha_atual'] ?? '';
        $nova  = $_POST['senha_nova'] ?? '';
        $conf  = $_POST['senha_conf'] ?? '';

        $erros = [];
        if (!password_verify($velha, $atual['senha']))        $erros[] = 'A senha atual está incorreta.';
        elseif (strlen($nova) < 6 || strlen($nova) > 72)       $erros[] = 'A nova senha deve ter entre 6 e 72 caracteres.';
        elseif ($nova !== $conf)                               $erros[] = 'A confirmação não confere com a nova senha.';
        if ($erros) $this->voltarComErros($erros, 'conta');

        $this->modelo()->alterarSenha((int)$atual['id'], $nova);
        session_regenerate_id(true);
        Session::flash('sucesso', 'Senha alterada com sucesso.');
        redirect('conta');
    }

    public function pedidos(): void
    {
        $this->view('conta/pedidos', [
            'titulo'  => 'Meus pedidos — Borges Games',
            'pedidos' => (new Pedido())->listarDoCliente((int)Session::usuario()['id']),
        ]);
    }

    public function pedido(int $id): void
    {
        $model  = new Pedido();
        $pedido = $model->buscarCompleto($id);
        // Cliente só enxerga os próprios pedidos.
        if (!$pedido || (int)$pedido['cliente_id'] !== (int)Session::usuario()['id']) $this->naoEncontrado();

        $this->view('conta/pedido', [
            'titulo' => "Pedido #$id — Borges Games",
            'pedido' => $pedido,
            'itens'  => $model->itens($id),
        ]);
    }
}
