<?php
namespace App\Controllers;

use App\Core\Carrinho;
use App\Core\Controller;
use App\Core\Session;
use App\Models\Game;
use App\Models\Pedido;

/** Carrinho de compras (sessão) e finalização do pedido. */
class CarrinhoController extends Controller
{
    public function index(): void
    {
        $itens = Carrinho::itens();
        $this->view('carrinho/index', [
            'titulo' => 'Meu carrinho — Borges Games',
            'itens'  => $itens,
            'total'  => Carrinho::total($itens),
        ]);
    }

    public function adicionar(): void
    {
        $id  = (int)$this->post('game_id');
        $qtd = max(1, (int)$this->post('qtd', '1'));

        $jogo = (new Game())->buscar($id);
        if (!$jogo || !$jogo['ativo']) {
            Session::flash('erro', 'Jogo indisponível.');
            redirect('');
        }
        $noCarrinho = Carrinho::bruto()[$id] ?? 0;
        if ($noCarrinho + $qtd > (int)$jogo['estoque']) {
            Session::flash('erro', "Estoque insuficiente de \"{$jogo['titulo']}\" (disponível: {$jogo['estoque']}).");
            redirect('jogo/' . $id);
        }

        Carrinho::adicionar($id, $qtd);
        Session::flash('sucesso', "\"{$jogo['titulo']}\" foi adicionado ao carrinho.");
        redirect('carrinho');
    }

    public function atualizar(): void
    {
        $id  = (int)$this->post('game_id');
        $qtd = (int)$this->post('qtd');

        $jogo = (new Game())->buscar($id);
        if ($jogo && $qtd > (int)$jogo['estoque']) {
            Session::flash('erro', "Só há {$jogo['estoque']} unidade(s) de \"{$jogo['titulo']}\".");
            $qtd = (int)$jogo['estoque'];
        }
        Carrinho::atualizar($id, $qtd);
        redirect('carrinho');
    }

    public function remover(): void
    {
        Carrinho::remover((int)$this->post('game_id'));
        redirect('carrinho');
    }

    public function finalizar(): void
    {
        $itens = Carrinho::itens();
        if (!$itens) {
            Session::flash('erro', 'Seu carrinho está vazio.');
            redirect('carrinho');
        }
        $pagamento = $this->post('forma_pagamento');

        $linhas = array_map(fn($i) => ['game_id' => (int)$i['id'], 'qtd' => (int)$i['qtd']], $itens);
        try {
            $pedidoId = (new Pedido())->criar((int)Session::usuario()['id'], $linhas, $pagamento, 'pendente');
        } catch (\RuntimeException | \InvalidArgumentException $e) {
            Session::flash('erro', $e->getMessage());
            redirect('carrinho');
        }

        Carrinho::limpar();
        Session::flash('sucesso', "Pedido #$pedidoId realizado! Aguardando confirmação do pagamento.");
        redirect('conta/pedidos/' . $pedidoId);
    }
}
