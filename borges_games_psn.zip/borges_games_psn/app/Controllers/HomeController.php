<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Categoria;
use App\Models\Game;

/** Página inicial pública: destaques, busca, filtro por categoria e catálogo (dados do banco). */
class HomeController extends Controller
{
    public function index(): void
    {
        $busca       = $this->get('buscar');
        $categoriaId = (int)$this->get('categoria', '0');
        $ordem       = $this->get('ordem', 'recentes');

        $games      = new Game();
        $categorias = (new Categoria())->comJogosAtivos();
        $lista      = $games->listarPublico($busca, $categoriaId, $ordem);

        $categoriaAtiva = null;
        foreach ($categorias as $c) if ((int)$c['id'] === $categoriaId) $categoriaAtiva = $c;

        $filtrando = ($busca !== '' || $categoriaId > 0);

        $this->view('home/index', [
            'titulo'         => 'Borges Games — Compre jogos digitais',
            'jogos'          => $lista,
            'categorias'     => $categorias,
            'categoriaAtiva' => $categoriaAtiva,
            'categoriaId'    => $categoriaId,
            'busca'          => $busca,
            'ordem'          => $ordem,
            'destaques'      => $filtrando ? [] : $games->destaques(4),
        ]);
    }
}
