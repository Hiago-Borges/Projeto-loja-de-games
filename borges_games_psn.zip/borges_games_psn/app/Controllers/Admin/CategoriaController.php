<?php
namespace App\Controllers\Admin;

use App\Core\Config;
use App\Core\Controller;
use App\Core\Model;
use App\Core\Session;
use App\Core\Validator;
use App\Models\Categoria;

/** CRUD de categorias. */
class CategoriaController extends Controller
{
    private function validar(array $d, int $ignorarId, string $voltar): void
    {
        $erros = Validator::validar($d, ['nome' => 'required|min:2|max:80', 'descricao' => 'max:255'],
                                    ['nome' => 'Nome', 'descricao' => 'Descrição']);
        if (!isset($erros['nome']) && (new Categoria())->nomeEmUso($d['nome'], $ignorarId)) {
            $erros['nome'] = 'Já existe uma categoria com esse nome.';
        }
        if ($erros) $this->voltarComErros($erros, $voltar);
    }

    private function dados(): array
    {
        return ['nome' => $this->post('nome'), 'descricao' => $this->post('descricao')];
    }

    public function index(): void
    {
        $busca = $this->get('buscar');
        $this->view('admin/categorias/index', [
            'titulo' => 'Categorias — Borges Games',
            'busca'  => $busca,
            'lista'  => (new Categoria())->listar($busca, (int)$this->get('pagina', '1'), Config::get('app.por_pagina')),
        ], 'admin');
    }

    public function criar(): void
    {
        $this->view('admin/categorias/form', ['titulo' => 'Nova categoria', 'categoria' => null], 'admin');
    }

    public function salvar(): void
    {
        $d = $this->dados();
        $this->validar($d, 0, 'admin/categorias/novo');
        (new Categoria())->criar($d);
        Session::flash('sucesso', 'Categoria cadastrada com sucesso!');
        redirect('admin/categorias');
    }

    public function editar(int $id): void
    {
        $c = (new Categoria())->buscar($id) ?? $this->naoEncontrado();
        $this->view('admin/categorias/form', ['titulo' => 'Editar categoria', 'categoria' => $c], 'admin');
    }

    public function atualizar(int $id): void
    {
        $model = new Categoria();
        $model->buscar($id) ?? $this->naoEncontrado();
        $d = $this->dados();
        $this->validar($d, $id, "admin/categorias/$id/editar");
        $model->atualizar($id, $d);
        Session::flash('sucesso', 'Categoria atualizada com sucesso!');
        redirect('admin/categorias');
    }

    public function excluir(int $id): void
    {
        try {
            (new Categoria())->excluir($id)
                ? Session::flash('sucesso', 'Categoria excluída.')
                : Session::flash('erro', 'Categoria não encontrada.');
        } catch (\PDOException $e) {
            Model::violouFk($e)
                ? Session::flash('erro', 'Não é possível excluir: existem jogos nesta categoria. Mova ou exclua os jogos antes.')
                : Session::flash('erro', 'Erro ao excluir a categoria.');
        }
        redirect('admin/categorias');
    }
}
