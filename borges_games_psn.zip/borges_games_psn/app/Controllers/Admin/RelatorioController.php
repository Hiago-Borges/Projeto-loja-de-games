<?php
namespace App\Controllers\Admin;

use App\Core\Controller;
use App\Models\Pedido;

/** Relatório de vendas por período. */
class RelatorioController extends Controller
{
    private function dataValida(string $d, string $padrao): string
    {
        $dt = \DateTime::createFromFormat('Y-m-d', $d);
        return ($dt && $dt->format('Y-m-d') === $d) ? $d : $padrao;
    }

    public function vendas(): void
    {
        $ini = $this->dataValida($this->get('inicio'), date('Y-m-d', strtotime('-29 days')));
        $fim = $this->dataValida($this->get('fim'), date('Y-m-d'));
        if ($ini > $fim) [$ini, $fim] = [$fim, $ini];

        $m = new Pedido();
        $this->view('admin/relatorios/vendas', [
            'titulo'       => 'Relatório de vendas — Borges Games',
            'ini'          => $ini,
            'fim'          => $fim,
            'resumo'       => $m->resumo($ini, $fim),
            'porDia'       => $m->vendasPorDia($ini, $fim),
            'maisVendidos' => $m->maisVendidos($ini, $fim, 10),
            'porCategoria' => $m->vendasPorCategoria($ini, $fim),
            'porPagamento' => $m->vendasPorPagamento($ini, $fim),
        ], 'admin');
    }
}
