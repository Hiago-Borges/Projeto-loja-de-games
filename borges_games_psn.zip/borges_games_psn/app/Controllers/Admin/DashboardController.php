<?php
namespace App\Controllers\Admin;

use App\Core\Controller;
use App\Models\Cliente;
use App\Models\Game;
use App\Models\Pedido;

/** Dashboard administrativo: indicadores, gráfico de vendas e alertas de estoque. */
class DashboardController extends Controller
{
    public function index(): void
    {
        $games   = new Game();
        $pedidos = new Pedido();
        $fim = date('Y-m-d');
        $ini = date('Y-m-d', strtotime('-29 days'));

        // Monta 30 dias completos (dias sem venda = 0) para o gráfico.
        $porDia = array_column($pedidos->vendasPorDia($ini, $fim), 'receita', 'dia');
        $serie  = [];
        for ($i = 29; $i >= 0; $i--) {
            $d = date('Y-m-d', strtotime("-$i days"));
            $serie[] = ['dia' => $d, 'receita' => (float)($porDia[$d] ?? 0)];
        }

        $this->view('admin/dashboard/index', [
            'titulo'       => 'Dashboard — Borges Games',
            'estoque'      => $games->resumoEstoque(),
            'totalClientes'=> (new Cliente())->contar(),
            'porStatus'    => $pedidos->contarPorStatus(),
            'resumo30'     => $pedidos->resumo($ini, $fim),
            'serie'        => $serie,
            'maisVendidos' => $pedidos->maisVendidos($ini, $fim, 5),
            'estoqueBaixo' => $games->estoqueBaixo(6),
            'recentes'     => $pedidos->recentes(6),
        ], 'admin');
    }
}
