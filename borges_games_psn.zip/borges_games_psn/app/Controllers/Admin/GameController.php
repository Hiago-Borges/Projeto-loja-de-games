<?php
namespace App\Controllers\Admin;

use App\Core\Config;
use App\Core\Controller;
use App\Core\Model;
use App\Core\Session;
use App\Core\Upload;
use App\Core\Validator;
use App\Models\Categoria;
use App\Models\Game;

/** CRUD de jogos (produtos), com upload de imagem e controle de estoque. */
class GameController extends Controller
{
    private function dados(): array
    {
        return [
            'titulo'       => $this->post('titulo'),
            'descricao'    => $this->post('descricao'),
            'preco'        => $this->post('preco'),
            'estoque'      => $this->post('estoque'),
            'categoria_id' => $this->post('categoria_id'),
            'destaque'     => isset($_POST['destaque']) ? 1 : 0,
            'ativo'        => isset($_POST['ativo']) ? 1 : 0,
        ];
    }

    private function validar(array $d, string $voltar): void
    {
        $erros = Validator::validar($d, [
            'titulo'       => 'required|min:2|max:160',
            'descricao'    => 'required|min:10|max:2000',
            'preco'        => 'required|numeric|min_val:0|max_val:99999.99',
            'estoque'      => 'required|int|min_val:0|max_val:1000000',
            'categoria_id' => 'required|int',
        ], ['titulo' => 'Título', 'descricao' => 'Descrição', 'preco' => 'Preço', 'estoque' => 'Estoque', 'categoria_id' => 'Categoria']);

        if (!isset($erros['categoria_id']) && !(new Categoria())->buscar((int)$d['categoria_id'])) {
            $erros['categoria_id'] = 'Categoria inválida.';
        }
        if ($erros) $this->voltarComErros($erros, $voltar);
    }

    public function index(): void
    {
        $busca = $this->get('buscar');
        $cat   = (int)$this->get('categoria', '0');
        $model = new Game();
        $this->view('admin/games/index', [
            'titulo'     => 'Jogos — Borges Games',
            'busca'      => $busca,
            'categoriaId'=> $cat,
            'categorias' => (new Categoria())->todas(),
            'lista'      => $model->listarAdmin($busca, $cat, (int)$this->get('pagina', '1'), Config::get('app.por_pagina')),
            'resumo'     => $model->resumoEstoque(),
        ], 'admin');
    }

    public function criar(): void
    {
        $this->view('admin/games/form', [
            'titulo' => 'Novo jogo', 'game' => null, 'categorias' => (new Categoria())->todas(),
        ], 'admin');
    }

    public function salvar(): void
    {
        $d = $this->dados();
        $this->validar($d, 'admin/games/novo');
        try {
            $d['imagem'] = Upload::imagem($_FILES['imagem'] ?? null);
        } catch (\RuntimeException $e) {
            $this->voltarComErros([$e->getMessage()], 'admin/games/novo');
        }
        (new Game())->criar($d);
        Session::flash('sucesso', 'Jogo cadastrado com sucesso!');
        redirect('admin/games');
    }

    public function editar(int $id): void
    {
        $g = (new Game())->buscar($id) ?? $this->naoEncontrado();
        $this->view('admin/games/form', [
            'titulo' => 'Editar jogo', 'game' => $g, 'categorias' => (new Categoria())->todas(),
        ], 'admin');
    }

    public function atualizar(int $id): void
    {
        $model = new Game();
        $atual = $model->buscar($id) ?? $this->naoEncontrado();
        $d = $this->dados();
        $this->validar($d, "admin/games/$id/editar");

        try {
            $nova = Upload::imagem($_FILES['imagem'] ?? null);
        } catch (\RuntimeException $e) {
            $this->voltarComErros([$e->getMessage()], "admin/games/$id/editar");
        }
        $d['imagem'] = $nova ?? $atual['imagem'];
        $model->atualizar($id, $d);
        if ($nova && $atual['imagem']) Upload::remover($atual['imagem']); // apaga a capa antiga

        Session::flash('sucesso', 'Jogo atualizado com sucesso!');
        redirect('admin/games');
    }

    public function excluir(int $id): void
    {
        $model = new Game();
        $g = $model->buscar($id) ?? $this->naoEncontrado();
        try {
            $model->excluir($id);
            Upload::remover($g['imagem']);
            Session::flash('sucesso', 'Jogo excluído com sucesso!');
        } catch (\PDOException $e) {
            Model::violouFk($e)
                ? Session::flash('erro', 'Este jogo já foi vendido e não pode ser excluído. Edite-o e desmarque "Ativo" para ocultá-lo da loja.')
                : Session::flash('erro', 'Erro ao excluir o jogo.');
        }
        redirect('admin/games');
    }
}
