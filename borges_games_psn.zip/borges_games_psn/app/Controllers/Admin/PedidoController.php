<?php
namespace App\Controllers\Admin;

use App\Core\Config;
use App\Core\Controller;
use App\Core\Session;
use App\Models\Cliente;
use App\Models\Game;
use App\Models\Pedido;

/** CRUD de pedidos (a baixa/devolução de estoque é feita no Model, em transação). */
class PedidoController extends Controller
{
    public function index(): void
    {
        $busca  = $this->get('buscar');
        $status = $this->get('status');
        $this->view('admin/pedidos/index', [
            'titulo' => 'Pedidos — Borges Games',
            'busca'  => $busca,
            'status' => $status,
            'lista'  => (new Pedido())->listar($busca, $status, (int)$this->get('pagina', '1'), Config::get('app.por_pagina')),
        ], 'admin');
    }

    public function ver(int $id): void
    {
        $model  = new Pedido();
        $pedido = $model->buscarCompleto($id) ?? $this->naoEncontrado();
        $this->view('admin/pedidos/ver', [
            'titulo' => "Pedido #$id",
            'pedido' => $pedido,
            'itens'  => $model->itens($id),
        ], 'admin');
    }

    public function criar(): void
    {
        $this->view('admin/pedidos/form', [
            'titulo'   => 'Novo pedido',
            'clientes' => (new Cliente())->todosAtivos(),
            'games'    => (new Game())->todosAtivos(),
        ], 'admin');
    }

    public function salvar(): void
    {
        $clienteId = (int)$this->post('cliente_id');
        if (!(new Cliente())->buscar($clienteId)) {
            $this->voltarComErros(['Selecione um cliente válido.'], 'admin/pedidos/novo');
        }

        $linhas = [];
        foreach ((array)($_POST['game_id'] ?? []) as $i => $gid) {
            $linhas[] = ['game_id' => (int)$gid, 'qtd' => (int)($_POST['qtd'][$i] ?? 0)];
        }

        try {
            $id = (new Pedido())->criar($clienteId, $linhas, $this->post('forma_pagamento'), $this->post('status', 'pendente'));
        } catch (\RuntimeException | \InvalidArgumentException $e) {
            $this->voltarComErros([$e->getMessage()], 'admin/pedidos/novo');
        }
        Session::flash('sucesso', "Pedido #$id criado com sucesso!");
        redirect('admin/pedidos/' . $id);
    }

    public function editar(int $id): void
    {
        $model  = new Pedido();
        $pedido = $model->buscarCompleto($id) ?? $this->naoEncontrado();
        $this->view('admin/pedidos/editar', [
            'titulo' => "Editar pedido #$id",
            'pedido' => $pedido,
            'itens'  => $model->itens($id),
        ], 'admin');
    }

    public function atualizar(int $id): void
    {
        $model = new Pedido();
        $model->buscar($id) ?? $this->naoEncontrado();
        try {
            $model->atualizar($id, $this->post('status'), $this->post('forma_pagamento'));
        } catch (\RuntimeException | \InvalidArgumentException $e) {
            $this->voltarComErros([$e->getMessage()], "admin/pedidos/$id/editar");
        }
        Session::flash('sucesso', 'Pedido atualizado com sucesso!');
        redirect('admin/pedidos/' . $id);
    }

    public function excluir(int $id): void
    {
        (new Pedido())->excluir($id)
            ? Session::flash('sucesso', "Pedido #$id excluído (estoque devolvido, se aplicável).")
            : Session::flash('erro', 'Pedido não encontrado.');
        redirect('admin/pedidos');
    }
}
