<?php
namespace App\Controllers\Admin;

use App\Core\Config;
use App\Core\Controller;
use App\Core\Session;
use App\Core\Validator;
use App\Models\Usuario;

/** CRUD de usuários da equipe (somente papel "admin"). */
class UsuarioController extends Controller
{
    private function dados(): array
    {
        return [
            'nome'  => $this->post('nome'),
            'email' => $this->post('email'),
            'papel' => $this->post('papel'),
            'senha' => $_POST['senha'] ?? '',
            'ativo' => isset($_POST['ativo']) ? 1 : 0,
        ];
    }

    private function validar(array $d, int $id, string $voltar): void
    {
        $erros = Validator::validar($d, [
            'nome'  => 'required|min:3|max:120',
            'email' => 'required|email|max:160',
            'papel' => 'required|in:admin,gerente',
            'senha' => ($id ? '' : 'required|') . 'min:6|max:72',
        ], ['nome' => 'Nome', 'email' => 'E-mail', 'papel' => 'Papel', 'senha' => 'Senha']);

        if (!isset($erros['email']) && (new Usuario())->emailEmUso($d['email'], $id)) {
            $erros['email'] = 'Este e-mail já está em uso.';
        }
        if ($erros) $this->voltarComErros($erros, $voltar);
    }

    public function index(): void
    {
        $busca = $this->get('buscar');
        $this->view('admin/usuarios/index', [
            'titulo' => 'Usuários — Borges Games',
            'busca'  => $busca,
            'lista'  => (new Usuario())->listar($busca, (int)$this->get('pagina', '1'), Config::get('app.por_pagina')),
        ], 'admin');
    }

    public function criar(): void
    {
        $this->view('admin/usuarios/form', ['titulo' => 'Novo usuário', 'usuario' => null], 'admin');
    }

    public function salvar(): void
    {
        $d = $this->dados();
        $this->validar($d, 0, 'admin/usuarios/novo');
        (new Usuario())->criar($d);
        Session::flash('sucesso', 'Usuário cadastrado com sucesso!');
        redirect('admin/usuarios');
    }

    public function editar(int $id): void
    {
        $u = (new Usuario())->buscar($id) ?? $this->naoEncontrado();
        $this->view('admin/usuarios/form', ['titulo' => 'Editar usuário', 'usuario' => $u], 'admin');
    }

    public function atualizar(int $id): void
    {
        $model = new Usuario();
        $atual = $model->buscar($id) ?? $this->naoEncontrado();
        $d = $this->dados();
        $this->validar($d, $id, "admin/usuarios/$id/editar");

        // Nunca deixar o sistema sem nenhum administrador ativo.
        $perdeAdmin = $atual['papel'] === 'admin' && $atual['ativo'] && ($d['papel'] !== 'admin' || !$d['ativo']);
        if ($perdeAdmin && $model->contarAdminsAtivos() <= 1) {
            $this->voltarComErros(['Este é o único administrador ativo. Não é possível rebaixá-lo ou desativá-lo.'], "admin/usuarios/$id/editar");
        }
        // Evita se trancar para fora do painel.
        if ($id === (int)Session::usuario()['id'] && !$d['ativo']) {
            $this->voltarComErros(['Você não pode desativar a sua própria conta.'], "admin/usuarios/$id/editar");
        }

        $model->atualizar($id, $d);
        if ($d['senha'] !== '') $model->alterarSenha($id, $d['senha']);

        if ($id === (int)Session::usuario()['id']) {      // mantém a sessão em sincronia
            $auth = Session::usuario();
            $auth['nome'] = $d['nome']; $auth['email'] = strtolower($d['email']); $auth['papel'] = $d['papel'];
            Session::set('auth', $auth);
        }
        Session::flash('sucesso', 'Usuário atualizado com sucesso!');
        redirect($id === (int)Session::usuario()['id'] && $d['papel'] !== 'admin' ? 'admin' : 'admin/usuarios');
    }

    public function excluir(int $id): void
    {
        $model = new Usuario();
        $u = $model->buscar($id) ?? $this->naoEncontrado();

        if ($id === (int)Session::usuario()['id']) {
            Session::flash('erro', 'Você não pode excluir a sua própria conta.');
        } elseif ($u['papel'] === 'admin' && $u['ativo'] && $model->contarAdminsAtivos() <= 1) {
            Session::flash('erro', 'Não é possível excluir o único administrador ativo.');
        } else {
            $model->excluir($id);
            Session::flash('sucesso', 'Usuário excluído.');
        }
        redirect('admin/usuarios');
    }
}
