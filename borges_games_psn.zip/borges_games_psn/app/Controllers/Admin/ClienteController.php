<?php
namespace App\Controllers\Admin;

use App\Core\Config;
use App\Core\Controller;
use App\Core\Model;
use App\Core\Session;
use App\Core\Validator;
use App\Models\Cliente;

/** CRUD de clientes. */
class ClienteController extends Controller
{
    private function dados(): array
    {
        return [
            'nome'     => $this->post('nome'),
            'email'    => $this->post('email'),
            'telefone' => $this->post('telefone'),
            'senha'    => $_POST['senha'] ?? '',
            'ativo'    => isset($_POST['ativo']) ? 1 : 0,
        ];
    }

    private function validar(array $d, int $id, string $voltar): void
    {
        $regras = [
            'nome'     => 'required|min:3|max:120',
            'email'    => 'required|email|max:160',
            'telefone' => 'required|telefone',
            'senha'    => ($id ? '' : 'required|') . 'min:6|max:72',   // na edição é opcional
        ];
        $erros = Validator::validar($d, $regras, ['nome' => 'Nome', 'email' => 'E-mail', 'telefone' => 'Telefone', 'senha' => 'Senha']);
        if (!isset($erros['email']) && (new Cliente())->emailEmUso($d['email'], $id)) {
            $erros['email'] = 'Este e-mail já está em uso.';
        }
        if ($erros) $this->voltarComErros($erros, $voltar);
    }

    public function index(): void
    {
        $busca = $this->get('buscar');
        $this->view('admin/clientes/index', [
            'titulo' => 'Clientes — Borges Games',
            'busca'  => $busca,
            'lista'  => (new Cliente())->listar($busca, (int)$this->get('pagina', '1'), Config::get('app.por_pagina')),
        ], 'admin');
    }

    public function criar(): void
    {
        $this->view('admin/clientes/form', ['titulo' => 'Novo cliente', 'cliente' => null], 'admin');
    }

    public function salvar(): void
    {
        $d = $this->dados();
        $this->validar($d, 0, 'admin/clientes/novo');
        (new Cliente())->criar($d);
        Session::flash('sucesso', 'Cliente cadastrado com sucesso!');
        redirect('admin/clientes');
    }

    public function editar(int $id): void
    {
        $c = (new Cliente())->buscar($id) ?? $this->naoEncontrado();
        $this->view('admin/clientes/form', ['titulo' => 'Editar cliente', 'cliente' => $c], 'admin');
    }

    public function atualizar(int $id): void
    {
        $model = new Cliente();
        $model->buscar($id) ?? $this->naoEncontrado();
        $d = $this->dados();
        $this->validar($d, $id, "admin/clientes/$id/editar");
        $model->atualizar($id, $d);
        if ($d['senha'] !== '') $model->alterarSenha($id, $d['senha']);
        Session::flash('sucesso', 'Cliente atualizado com sucesso!');
        redirect('admin/clientes');
    }

    public function excluir(int $id): void
    {
        try {
            (new Cliente())->excluir($id)
                ? Session::flash('sucesso', 'Cliente excluído.')
                : Session::flash('erro', 'Cliente não encontrado.');
        } catch (\PDOException $e) {
            Model::violouFk($e)
                ? Session::flash('erro', 'Este cliente possui pedidos e não pode ser excluído. Edite-o e desmarque "Ativo" para bloquear o acesso.')
                : Session::flash('erro', 'Erro ao excluir o cliente.');
        }
        redirect('admin/clientes');
    }
}
