<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Game;

/** Página de detalhes do jogo. */
class JogoController extends Controller
{
    public function ver(int $id): void
    {
        $model = new Game();
        $jogo  = $model->buscarCompleto($id);
        if (!$jogo || !$jogo['ativo']) $this->naoEncontrado();

        $this->view('jogo/ver', [
            'titulo'        => $jogo['titulo'] . ' — Borges Games',
            'jogo'          => $jogo,
            'relacionados'  => $model->relacionados((int)$jogo['categoria_id'], $id),
        ]);
    }
}
