<div class="container">
    <div class="loja-vazio" style="margin-top:40px">
        <span class="loja-vazio-icon">🕹️</span>
        <h1 style="font-size:28px;margin-bottom:6px"><?= (int)$codigo ?></h1>
        <p><?= e($mensagem) ?></p>
        <a href="<?= url('') ?>" class="btn btn-primario">Voltar à loja</a>
    </div>
</div>
