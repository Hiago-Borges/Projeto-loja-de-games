<?php
use App\Core\Session;
$auth     = Session::usuario();
$superAdm = ($auth['papel'] ?? '') === 'admin';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($titulo) ?></title>
    <link rel="stylesheet" href="<?= url('css/style.css') ?>">
    <link rel="stylesheet" href="<?= url('css/admin-extra.css') ?>">
</head>
<body class="admin-page">

<header class="admin-header">
    <div class="admin-header-inner">
        <a href="<?= url('admin') ?>" class="admin-logo"><span class="admin-logo-text">🎮 Borges Games</span></a>

        <nav class="admin-nav">
            <a href="<?= url('admin') ?>" class="admin-nav-link <?= rota_ativa('/admin') === 'ativo' && !preg_match('#/admin/.+#', $_SERVER['REQUEST_URI']) ? 'ativo' : '' ?>">📊 Dashboard</a>
            <a href="<?= url('admin/games') ?>"      class="admin-nav-link <?= rota_ativa('/admin/games') ?>">🎮 Jogos</a>
            <a href="<?= url('admin/categorias') ?>" class="admin-nav-link <?= rota_ativa('/admin/categorias') ?>">🏷️ Categorias</a>
            <a href="<?= url('admin/clientes') ?>"   class="admin-nav-link <?= rota_ativa('/admin/clientes') ?>">🧑 Clientes</a>
            <a href="<?= url('admin/pedidos') ?>"    class="admin-nav-link <?= rota_ativa('/admin/pedidos') ?>">🧾 Pedidos</a>
            <a href="<?= url('admin/relatorios') ?>" class="admin-nav-link <?= rota_ativa('/admin/relatorios') ?>">📈 Relatórios</a>
            <?php if ($superAdm): ?>
                <a href="<?= url('admin/usuarios') ?>" class="admin-nav-link <?= rota_ativa('/admin/usuarios') ?>">👥 Usuários</a>
            <?php endif; ?>
            <a href="<?= url('') ?>" class="admin-nav-link">🏬 Loja</a>
            <a href="<?= url('conta') ?>" class="admin-nav-link">👤 Perfil</a>
        </nav>

        <div class="admin-user-info">
            <span class="admin-user-nome">
                <?= e($auth['nome']) ?>
                <span class="badge-tipo badge-<?= $superAdm ? 'admin' : 'user' ?>"><?= e(ucfirst($auth['papel'] ?? 'gerente')) ?></span>
            </span>
            <form method="POST" action="<?= url('logout') ?>" class="form-inline">
                <?= csrf_field() ?>
                <button type="submit" class="admin-nav-link botao-link">Sair</button>
            </form>
        </div>
    </div>
</header>

<main class="admin-main">
    <?php App\Core\View::parcial('flash'); ?>
    <?= $conteudo ?>
</main>

<script src="<?= url('js/validacao.js') ?>"></script>
</body>
</html>
