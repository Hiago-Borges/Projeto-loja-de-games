<?php
use App\Core\Carrinho;
use App\Core\Session;

$auth     = Session::usuario();
$inicial  = $auth ? mb_substr($auth['nome'], 0, 1) : '';
$qtdCarr  = Carrinho::quantidadeTotal();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($titulo) ?></title>
    <link rel="stylesheet" href="<?= url('css/loja.css') ?>">
    <link rel="stylesheet" href="<?= url('css/loja-extra.css') ?>">
</head>
<body>

    <div class="faixa">
        <div class="faixa-inner">
            <span>⚡ Entrega <b>digital imediata</b></span>
            <span>💳 Parcele em até <b>3x sem juros</b></span>
            <span>🔒 Compra <b>100% segura</b></span>
        </div>
    </div>

    <header class="loja-header">
        <div class="loja-header-inner">
            <a href="<?= url('') ?>" class="loja-logo">
                <span class="loja-logo-icon">🎮</span>
                <span class="loja-logo-nome">Borges <b>Games</b></span>
            </a>

            <form method="GET" action="<?= url('') ?>" class="loja-busca" role="search">
                <?php if (!empty($categoriaId)): ?>
                    <input type="hidden" name="categoria" value="<?= (int)$categoriaId ?>">
                <?php endif; ?>
                <input type="text" name="buscar" placeholder="Buscar jogos..."
                       value="<?= e($busca ?? '') ?>" aria-label="Buscar jogos">
                <button type="submit" aria-label="Buscar">🔍</button>
            </form>

            <div class="loja-conta">
                <a href="<?= url('carrinho') ?>" class="btn-link carrinho-link" aria-label="Carrinho">
                    🛒 Carrinho<?php if ($qtdCarr > 0): ?> <span class="carrinho-qtd"><?= $qtdCarr ?></span><?php endif; ?>
                </a>
                <?php if ($auth): ?>
                    <?php if ($auth['tipo'] === 'admin'): ?>
                        <a href="<?= url('admin') ?>" class="btn-link">Painel</a>
                    <?php else: ?>
                        <a href="<?= url('conta/pedidos') ?>" class="btn-link">Meus pedidos</a>
                    <?php endif; ?>
                    <a href="<?= url('conta') ?>" class="usuario-chip">
                        <span class="avatar"><?= e($inicial) ?></span>
                        <?= e($auth['nome']) ?>
                    </a>
                    <form method="POST" action="<?= url('logout') ?>" class="form-inline">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn-link btn-link-botao">Sair</button>
                    </form>
                <?php else: ?>
                    <a href="<?= url('login') ?>" class="btn-link">Entrar</a>
                    <a href="<?= url('cadastro') ?>" class="btn btn-primario btn-sm">Criar conta</a>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($categorias)): ?>
        <nav class="loja-nav" aria-label="Categorias">
            <div class="loja-nav-inner">
                <a href="<?= url('') ?>" class="<?= empty($categoriaId) ? 'ativo' : '' ?>">Todos os jogos</a>
                <?php foreach ($categorias as $c): ?>
                    <a href="<?= url('?categoria=' . (int)$c['id']) ?>#catalogo"
                       class="<?= (int)($categoriaId ?? 0) === (int)$c['id'] ? 'ativo' : '' ?>"><?= e($c['nome']) ?></a>
                <?php endforeach; ?>
            </div>
        </nav>
        <?php endif; ?>
    </header>

    <main>
        <div class="container flash-area"><?php App\Core\View::parcial('flash'); ?></div>
        <?= $conteudo ?>
    </main>

    <footer class="loja-footer">
        <div class="loja-footer-inner">
            <div>
                <strong>Borges Games</strong>
                Jogos digitais para todos os jogadores.
            </div>
            <div>Carlos Eduardo R.B — UNIFIPMoc</div>
        </div>
    </footer>

    <script src="<?= url('js/validacao.js') ?>"></script>
</body>
</html>
