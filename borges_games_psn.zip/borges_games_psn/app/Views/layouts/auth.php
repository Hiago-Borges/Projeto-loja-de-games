<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($titulo) ?></title>
    <link rel="stylesheet" href="<?= url('css/loja.css') ?>">
    <link rel="stylesheet" href="<?= url('css/loja-extra.css') ?>">
</head>
<body class="login-page">
    <main>
        <div class="login-wrapper">
            <div class="login-emblem">🎮</div>
            <h1 class="login-title">Borges <b>Games</b></h1>
            <?php App\Core\View::parcial('flash'); ?>
            <?= $conteudo ?>
            <p class="login-rodape"><a href="<?= url('') ?>">← Voltar à Loja</a></p>
        </div>
    </main>
    <script src="<?= url('js/validacao.js') ?>"></script>
</body>
</html>
