<?php if ($destaques): $p = $destaques[0]; $laterais = array_slice($destaques, 1); ?>
<section class="destaques">
    <div class="container destaques-grid">
        <article class="destaque-principal">
            <img class="bg" src="<?= e(img_url($p['imagem'])) ?>" alt="">
            <div class="destaque-conteudo">
                <span class="selo">Destaque</span>
                <h1 class="destaque-titulo"><?= e($p['titulo']) ?></h1>
                <p class="destaque-desc"><?= e($p['descricao']) ?></p>
                <div class="destaque-compra">
                    <span class="destaque-preco"><?= preco($p['preco']) ?></span>
                    <a href="<?= url('jogo/' . (int)$p['id']) ?>" class="btn btn-primario btn-lg">Ver jogo</a>
                </div>
            </div>
        </article>

        <?php if ($laterais): ?>
        <div class="destaque-lateral">
            <?php foreach ($laterais as $l): ?>
                <a href="<?= url('jogo/' . (int)$l['id']) ?>" class="mini">
                    <div class="mini-img"><img src="<?= e(img_url($l['imagem'])) ?>" alt=""></div>
                    <div class="mini-info">
                        <div class="mini-titulo"><?= e($l['titulo']) ?></div>
                        <div class="mini-cat"><?= e($l['categoria']) ?></div>
                        <div class="mini-preco"><?= preco($l['preco']) ?></div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<section class="catalogo" id="catalogo">
    <div class="container">
        <div class="catalogo-topo">
            <h2 class="secao-titulo">
                <?php if ($busca !== ''): ?>
                    Resultados para <em>“<?= e($busca) ?>”</em>
                <?php elseif ($categoriaAtiva): ?>
                    <?= e($categoriaAtiva['nome']) ?>
                <?php else: ?>
                    Catálogo de jogos
                <?php endif; ?>
                <span class="secao-contagem"><?= count($jogos) ?> <?= count($jogos) === 1 ? 'jogo' : 'jogos' ?></span>
            </h2>

            <div class="catalogo-acoes">
                <form method="GET" action="<?= url('') ?>#catalogo" class="ordenar">
                    <?php if ($busca !== ''): ?><input type="hidden" name="buscar" value="<?= e($busca) ?>"><?php endif; ?>
                    <?php if ($categoriaId): ?><input type="hidden" name="categoria" value="<?= (int)$categoriaId ?>"><?php endif; ?>
                    <label for="ordem" class="sr-only">Ordenar</label>
                    <select name="ordem" id="ordem" onchange="this.form.submit()">
                        <?php foreach (['recentes' => 'Mais recentes', 'nome' => 'Nome (A–Z)', 'menor' => 'Menor preço', 'maior' => 'Maior preço'] as $v => $r): ?>
                            <option value="<?= $v ?>" <?= $ordem === $v ? 'selected' : '' ?>><?= $r ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>
                <?php if ($busca !== '' || $categoriaId): ?>
                    <a href="<?= url('') ?>" class="btn btn-fantasma btn-sm">✕ Limpar filtros</a>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($categorias): ?>
        <div class="chips">
            <a href="<?= url($busca !== '' ? '?buscar=' . urlencode($busca) : '') ?>#catalogo"
               class="chip <?= !$categoriaId ? 'ativo' : '' ?>">Todos</a>
            <?php foreach ($categorias as $c): ?>
                <a href="<?= url('?categoria=' . (int)$c['id'] . ($busca !== '' ? '&buscar=' . urlencode($busca) : '')) ?>#catalogo"
                   class="chip <?= $categoriaId === (int)$c['id'] ? 'ativo' : '' ?>"><?= e($c['nome']) ?></a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if ($jogos): ?>
            <div class="loja-grid">
                <?php foreach ($jogos as $g): $img = img_url($g['imagem']); $esgotado = (int)$g['estoque'] <= 0; ?>
                    <article class="game-card <?= $esgotado ? 'esgotado' : '' ?>">
                        <a class="game-card-link" href="<?= url('jogo/' . (int)$g['id']) ?>" aria-label="<?= e($g['titulo']) ?>"></a>

                        <div class="game-card-img">
                            <?php if ($img): ?>
                                <img src="<?= e($img) ?>" alt="<?= e($g['titulo']) ?>" loading="lazy">
                            <?php else: ?>
                                <div class="game-card-sem-img">🎮</div>
                            <?php endif; ?>
                            <?php if ($esgotado): ?>
                                <span class="tag-esgotado">Esgotado</span>
                            <?php elseif ((int)$g['estoque'] <= 5): ?>
                                <span class="tag-ultimas">Últimas <?= (int)$g['estoque'] ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="game-card-body">
                            <span class="game-card-categoria"><?= e($g['categoria']) ?></span>
                            <h3 class="game-card-titulo"><?= e($g['titulo']) ?></h3>
                            <p class="game-card-desc"><?= e($g['descricao']) ?></p>

                            <div class="game-card-preco-bloco">
                                <div class="game-card-preco"><?= preco($g['preco']) ?></div>
                                <?php if (!$esgotado): ?>
                                    <div class="game-card-parcela">ou <b><?= e(parcela($g['preco'])) ?></b></div>
                                <?php else: ?>
                                    <div class="game-card-parcela">Indisponível no momento</div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="loja-vazio">
                <span class="loja-vazio-icon">🕹️</span>
                <p>Nenhum jogo encontrado.</p>
                <a href="<?= url('') ?>" class="btn btn-primario">Ver todos os jogos</a>
            </div>
        <?php endif; ?>
    </div>
</section>
