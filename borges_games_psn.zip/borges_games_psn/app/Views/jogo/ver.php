<?php
$g        = $jogo;
$img      = img_url($g['imagem']);
$esgotado = (int)$g['estoque'] <= 0;
$noCarrinho = \App\Core\Carrinho::bruto()[$g['id']] ?? 0;
?>
<div class="container">
    <nav class="breadcrumb">
        <a href="<?= url('') ?>">Loja</a><span>›</span>
        <a href="<?= url('?categoria=' . (int)$g['categoria_id']) ?>#catalogo"><?= e($g['categoria']) ?></a><span>›</span>
        <?= e($g['titulo']) ?>
    </nav>

    <div class="produto">
        <div class="produto-midia">
            <?php if ($img): ?>
                <img src="<?= e($img) ?>" alt="<?= e($g['titulo']) ?>">
            <?php else: ?>
                <div class="game-card-sem-img">🎮</div>
            <?php endif; ?>
            <div class="produto-descricao">
                <h2>Sobre o jogo</h2>
                <p><?= nl2br(e($g['descricao'])) ?></p>
            </div>
        </div>

        <aside class="produto-compra">
            <span class="game-card-categoria"><?= e($g['categoria']) ?></span>
            <h1><?= e($g['titulo']) ?></h1>

            <?php if ($esgotado): ?>
                <span class="estoque-zero">Esgotado</span>
            <?php elseif ((int)$g['estoque'] <= 5): ?>
                <span class="estoque-baixo">Últimas <?= (int)$g['estoque'] ?> unidades</span>
            <?php else: ?>
                <span class="estoque-ok"><?= (int)$g['estoque'] ?> em estoque</span>
            <?php endif; ?>

            <div class="produto-preco"><?= preco($g['preco']) ?></div>
            <div class="produto-parcela">ou <b><?= e(parcela($g['preco'])) ?></b></div>

            <?php if ($esgotado): ?>
                <span class="btn btn-primario btn-bloco btn-lg desabilitado">Indisponível</span>
            <?php else: ?>
                <form method="POST" action="<?= url('carrinho/adicionar') ?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="game_id" value="<?= (int)$g['id'] ?>">
                    <input type="hidden" name="qtd" value="1">
                    <button type="submit" class="btn btn-primario btn-bloco btn-lg">🛒 Adicionar ao carrinho</button>
                </form>
                <?php if ($noCarrinho): ?>
                    <p class="produto-aviso"><?= (int)$noCarrinho ?> unidade(s) já no seu carrinho · <a href="<?= url('carrinho') ?>">ver carrinho</a></p>
                <?php endif; ?>
            <?php endif; ?>

            <ul class="produto-beneficios">
                <li>⚡ Entrega digital imediata</li>
                <li>💳 Parcele em até 3x sem juros</li>
                <li>🔒 Compra 100% segura</li>
            </ul>
        </aside>
    </div>

    <?php if ($relacionados): ?>
    <section class="relacionados">
        <h2 class="secao-titulo">Mais em <?= e($g['categoria']) ?></h2>
        <div class="loja-grid">
            <?php foreach ($relacionados as $r): $ri = img_url($r['imagem']); ?>
                <article class="game-card">
                    <a class="game-card-link" href="<?= url('jogo/' . (int)$r['id']) ?>" aria-label="<?= e($r['titulo']) ?>"></a>
                    <div class="game-card-img">
                        <?php if ($ri): ?><img src="<?= e($ri) ?>" alt="<?= e($r['titulo']) ?>" loading="lazy">
                        <?php else: ?><div class="game-card-sem-img">🎮</div><?php endif; ?>
                    </div>
                    <div class="game-card-body">
                        <h3 class="game-card-titulo"><?= e($r['titulo']) ?></h3>
                        <div class="game-card-preco"><?= preco($r['preco']) ?></div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>
</div>
