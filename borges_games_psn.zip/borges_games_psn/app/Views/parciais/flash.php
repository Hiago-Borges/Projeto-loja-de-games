<?php use App\Core\Session; ?>
<?php foreach (Session::pegarFlash() as $f): ?>
    <div class="alerta <?= $f['tipo'] === 'sucesso' ? 'alerta-sucesso' : 'alerta-erro' ?>" role="alert"><?= e($f['msg']) ?></div>
<?php endforeach; ?>
