<?php
// Espera $lista com 'pagina' e 'paginas'. Mantém os filtros da URL (busca, status, etc.).
if (($lista['paginas'] ?? 1) > 1):
    $q = $_GET; unset($q['pagina']);
?>
<nav class="paginacao" aria-label="Paginação">
    <?php for ($p = 1; $p <= $lista['paginas']; $p++): $q['pagina'] = $p; ?>
        <a href="?<?= e(http_build_query($q)) ?>" class="<?= $p === $lista['pagina'] ? 'ativo' : '' ?>"><?= $p ?></a>
    <?php endfor; ?>
</nav>
<?php endif; ?>
