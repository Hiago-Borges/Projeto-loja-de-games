<?php
use App\Core\Session;
$ehAdmin = Session::ehAdmin();
$inicial = mb_substr($dados['nome'], 0, 1);
?>
<div class="container">
    <div class="perfil-topo">
        <span class="perfil-avatar"><?= e($inicial) ?></span>
        <div>
            <h1><?= e($dados['nome']) ?></h1>
            <p><?= e($dados['email']) ?>
               <span class="badge-perfil <?= $ehAdmin ? 'admin' : '' ?>"><?= $ehAdmin ? e(ucfirst($dados['papel'])) : 'Cliente' ?></span></p>
        </div>
    </div>

    <div class="perfil-grid">
        <section class="perfil-card">
            <h2>Dados da conta</h2>
            <form method="POST" action="<?= url('conta/dados') ?>" data-validar>
                <?= csrf_field() ?>
                <div class="campo-grupo">
                    <label for="nome">Nome</label>
                    <input type="text" id="nome" name="nome" value="<?= e(old('nome', $dados['nome'])) ?>" minlength="3" maxlength="120" required>
                </div>
                <div class="campo-grupo">
                    <label for="email">E-mail</label>
                    <input type="email" id="email" name="email" value="<?= e(old('email', $dados['email'])) ?>" maxlength="160" required>
                </div>
                <?php if (!$ehAdmin): ?>
                <div class="campo-grupo">
                    <label for="telefone">Telefone</label>
                    <input type="tel" id="telefone" name="telefone" value="<?= e(old('telefone', telefone_fmt($dados['telefone']))) ?>"
                           data-mask="telefone" data-tipo="telefone" required>
                </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-primario">Salvar alterações</button>
            </form>
        </section>

        <section class="perfil-card">
            <h2>Alterar senha</h2>
            <form method="POST" action="<?= url('conta/senha') ?>" data-validar>
                <?= csrf_field() ?>
                <div class="campo-grupo">
                    <label for="senha_atual">Senha atual</label>
                    <input type="password" id="senha_atual" name="senha_atual" required>
                </div>
                <div class="campo-grupo">
                    <label for="senha_nova">Nova senha</label>
                    <input type="password" id="senha_nova" name="senha_nova" minlength="6" maxlength="72" required>
                    <small class="campo-dica">Mínimo de 6 caracteres</small>
                </div>
                <div class="campo-grupo">
                    <label for="senha_conf">Confirmar nova senha</label>
                    <input type="password" id="senha_conf" name="senha_conf" data-igual="senha_nova" required>
                </div>
                <button type="submit" class="btn btn-primario">Alterar senha</button>
            </form>
        </section>
    </div>
</div>
