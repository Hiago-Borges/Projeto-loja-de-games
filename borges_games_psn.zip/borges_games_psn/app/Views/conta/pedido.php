<div class="container">
    <nav class="breadcrumb">
        <a href="<?= url('conta/pedidos') ?>">Meus pedidos</a><span>›</span> Pedido #<?= (int)$pedido['id'] ?>
    </nav>

    <div class="pedido-topo">
        <h1 class="pagina-titulo">Pedido #<?= (int)$pedido['id'] ?></h1>
        <span class="status status-<?= e($pedido['status']) ?>"><?= e(rotulo_status($pedido['status'])) ?></span>
    </div>
    <p class="pedido-meta">Feito em <?= data_br($pedido['created_at']) ?> · Pagamento: <?= e(rotulo_pagamento($pedido['forma_pagamento'])) ?></p>

    <?php if ($pedido['status'] === 'pendente'): ?>
        <div class="alerta alerta-erro">Aguardando a confirmação do pagamento pela loja.</div>
    <?php elseif ($pedido['status'] === 'pago'): ?>
        <div class="alerta alerta-sucesso">Pagamento confirmado! Seus jogos digitais estão liberados.</div>
    <?php endif; ?>

    <div class="tabela-loja-wrap">
        <table class="tabela-loja">
            <thead><tr><th>Jogo</th><th>Preço</th><th>Qtd</th><th>Subtotal</th></tr></thead>
            <tbody>
            <?php foreach ($itens as $i): ?>
                <tr>
                    <td><a href="<?= url('jogo/' . (int)$i['game_id']) ?>"><?= e($i['titulo']) ?></a></td>
                    <td><?= preco($i['preco_unitario']) ?></td>
                    <td><?= (int)$i['quantidade'] ?></td>
                    <td><b><?= preco($i['subtotal']) ?></b></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td colspan="3" style="text-align:right">Total</td><td><b><?= preco($pedido['total']) ?></b></td></tr></tfoot>
        </table>
    </div>
</div>
