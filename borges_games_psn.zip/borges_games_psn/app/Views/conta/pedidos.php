<div class="container">
    <h1 class="pagina-titulo">🧾 Meus pedidos</h1>

    <?php if (!$pedidos): ?>
        <div class="loja-vazio">
            <span class="loja-vazio-icon">🧾</span>
            <p>Você ainda não fez nenhum pedido.</p>
            <a href="<?= url('') ?>" class="btn btn-primario">Ver jogos</a>
        </div>
    <?php else: ?>
        <div class="tabela-loja-wrap">
            <table class="tabela-loja">
                <thead><tr><th>Pedido</th><th>Data</th><th>Itens</th><th>Pagamento</th><th>Total</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($pedidos as $p): ?>
                    <tr>
                        <td><b>#<?= (int)$p['id'] ?></b></td>
                        <td><?= data_br($p['created_at']) ?></td>
                        <td><?= (int)$p['qtd_itens'] ?></td>
                        <td><?= e(rotulo_pagamento($p['forma_pagamento'])) ?></td>
                        <td><b><?= preco($p['total']) ?></b></td>
                        <td><span class="status status-<?= e($p['status']) ?>"><?= e(rotulo_status($p['status'])) ?></span></td>
                        <td><a href="<?= url('conta/pedidos/' . (int)$p['id']) ?>" class="btn btn-fantasma btn-sm">Detalhes</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
