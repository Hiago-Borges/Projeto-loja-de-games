<p class="login-subtitle">Crie sua conta de cliente</p>

<form method="POST" action="<?= url('cadastro') ?>" class="login-form" data-validar novalidate>
    <?= csrf_field() ?>
    <div class="campo-grupo">
        <label for="nome">Nome completo <span class="obrigatorio">*</span></label>
        <input type="text" id="nome" name="nome" value="<?= e(old('nome')) ?>" minlength="3" maxlength="120" required>
    </div>
    <div class="campo-grupo">
        <label for="email">E-mail <span class="obrigatorio">*</span></label>
        <input type="email" id="email" name="email" value="<?= e(old('email')) ?>" maxlength="160" required>
    </div>
    <div class="campo-grupo">
        <label for="telefone">Telefone (com DDD) <span class="obrigatorio">*</span></label>
        <input type="tel" id="telefone" name="telefone" value="<?= e(old('telefone')) ?>" placeholder="(38) 99999-9999"
               data-mask="telefone" data-tipo="telefone" required>
    </div>
    <div class="campo-grupo">
        <label for="senha">Senha <span class="obrigatorio">*</span></label>
        <input type="password" id="senha" name="senha" minlength="6" maxlength="72" required>
        <small class="campo-dica">Mínimo de 6 caracteres</small>
    </div>
    <div class="campo-grupo">
        <label for="senha_confirmacao">Confirmar senha <span class="obrigatorio">*</span></label>
        <input type="password" id="senha_confirmacao" name="senha_confirmacao" data-igual="senha" required>
    </div>
    <button type="submit" class="btn btn-primario btn-bloco">Criar conta</button>
</form>

<div class="login-divider"><span>já tem conta?</span></div>
<a href="<?= url('login') ?>" class="btn btn-secundario btn-bloco">Entrar</a>
