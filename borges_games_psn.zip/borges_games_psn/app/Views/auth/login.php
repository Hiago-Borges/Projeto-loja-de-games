<p class="login-subtitle">Entre na sua conta para continuar</p>

<form method="POST" action="<?= url('login') ?>" class="login-form" data-validar>
    <?= csrf_field() ?>
    <div class="campo-grupo">
        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" placeholder="seu@email.com" value="<?= e(old('email')) ?>" required autofocus>
    </div>
    <div class="campo-grupo">
        <label for="senha">Senha</label>
        <input type="password" id="senha" name="senha" placeholder="••••••••" required>
    </div>
    <button type="submit" class="btn btn-primario btn-bloco">Entrar</button>
</form>

<div class="login-divider"><span>ou</span></div>
<a href="<?= url('cadastro') ?>" class="btn btn-secundario btn-bloco">Criar conta de cliente</a>
