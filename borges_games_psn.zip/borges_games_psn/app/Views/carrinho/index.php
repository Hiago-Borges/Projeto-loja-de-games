<?php use App\Core\Session; ?>
<div class="container">
    <h1 class="pagina-titulo">🛒 Meu carrinho</h1>

    <?php if (!$itens): ?>
        <div class="loja-vazio">
            <span class="loja-vazio-icon">🛒</span>
            <p>Seu carrinho está vazio.</p>
            <a href="<?= url('') ?>" class="btn btn-primario">Ver jogos</a>
        </div>
    <?php else: ?>
    <div class="carrinho-grid">
        <section class="carrinho-itens">
            <?php foreach ($itens as $i): $img = img_url($i['imagem']); ?>
                <article class="carrinho-item">
                    <a href="<?= url('jogo/' . (int)$i['id']) ?>" class="carrinho-img">
                        <?php if ($img): ?><img src="<?= e($img) ?>" alt=""><?php else: ?><span>🎮</span><?php endif; ?>
                    </a>
                    <div class="carrinho-info">
                        <a href="<?= url('jogo/' . (int)$i['id']) ?>" class="carrinho-titulo"><?= e($i['titulo']) ?></a>
                        <span class="game-card-categoria"><?= e($i['categoria']) ?></span>
                        <span class="carrinho-unit"><?= preco($i['preco']) ?> cada</span>
                    </div>

                    <form method="POST" action="<?= url('carrinho/atualizar') ?>" class="carrinho-qtd-form">
                        <?= csrf_field() ?>
                        <input type="hidden" name="game_id" value="<?= (int)$i['id'] ?>">
                        <label class="sr-only" for="qtd<?= (int)$i['id'] ?>">Quantidade</label>
                        <input type="number" id="qtd<?= (int)$i['id'] ?>" name="qtd" min="1" max="<?= (int)$i['estoque'] ?>"
                               value="<?= (int)$i['qtd'] ?>">
                        <button type="submit" class="btn btn-fantasma btn-sm">Atualizar</button>
                    </form>

                    <div class="carrinho-subtotal"><?= preco($i['subtotal']) ?></div>

                    <form method="POST" action="<?= url('carrinho/remover') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="game_id" value="<?= (int)$i['id'] ?>">
                        <button type="submit" class="carrinho-remover" aria-label="Remover <?= e($i['titulo']) ?>" title="Remover">✕</button>
                    </form>
                </article>
            <?php endforeach; ?>
        </section>

        <aside class="carrinho-resumo">
            <h2>Resumo</h2>
            <div class="resumo-linha"><span>Itens</span><b><?= array_sum(array_column($itens, 'qtd')) ?></b></div>
            <div class="resumo-linha total"><span>Total</span><b><?= preco($total) ?></b></div>
            <div class="resumo-parcela">ou <?= e(parcela($total)) ?></div>

            <?php if (Session::ehCliente()): ?>
                <form method="POST" action="<?= url('carrinho/finalizar') ?>" data-validar>
                    <?= csrf_field() ?>
                    <div class="campo-grupo">
                        <label for="forma_pagamento">Forma de pagamento</label>
                        <select id="forma_pagamento" name="forma_pagamento" required>
                            <option value="pix">PIX</option>
                            <option value="cartao">Cartão de crédito</option>
                            <option value="boleto">Boleto</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primario btn-bloco btn-lg">Finalizar compra</button>
                </form>
            <?php elseif (Session::ehAdmin()): ?>
                <div class="alerta alerta-erro">Contas da equipe não fazem compras. Entre com uma conta de cliente.</div>
            <?php else: ?>
                <a href="<?= url('login') ?>" class="btn btn-primario btn-bloco btn-lg">Entrar para finalizar</a>
                <p class="resumo-dica">Não tem conta? <a href="<?= url('cadastro') ?>">Cadastre-se grátis</a>.</p>
            <?php endif; ?>
        </aside>
    </div>
    <?php endif; ?>
</div>
