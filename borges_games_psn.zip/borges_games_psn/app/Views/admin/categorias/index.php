<div class="admin-page-topo">
    <h2 class="admin-titulo"><span class="titulo-icone">🏷️</span> Categorias</h2>
</div>

<div class="top-bar">
    <form method="GET" action="<?= url('admin/categorias') ?>" class="form-busca">
        <input type="text" name="buscar" placeholder="Buscar categoria..." value="<?= e($busca) ?>">
        <button type="submit" class="btn btn-secundario">🔍 Buscar</button>
        <?php if ($busca !== ''): ?><a href="<?= url('admin/categorias') ?>" class="btn btn-fantasma">✕ Limpar</a><?php endif; ?>
    </form>
    <a href="<?= url('admin/categorias/novo') ?>" class="btn btn-primario">+ Nova Categoria</a>
</div>

<div class="tabela-wrapper">
    <table class="tabela-admin">
        <thead><tr><th>ID</th><th>Nome</th><th>Descrição</th><th>Jogos</th><th>Ações</th></tr></thead>
        <tbody>
        <?php if ($lista['dados']): foreach ($lista['dados'] as $c): ?>
            <tr>
                <td><?= (int)$c['id'] ?></td>
                <td><b><?= e($c['nome']) ?></b></td>
                <td class="td-descricao"><?= e($c['descricao'] ?? '—') ?></td>
                <td><?= (int)$c['total_games'] ?></td>
                <td class="acoes">
                    <a href="<?= url('admin/categorias/' . (int)$c['id'] . '/editar') ?>" class="btn-acao btn-editar" title="Editar">✏</a>
                    <form method="POST" action="<?= url('admin/categorias/' . (int)$c['id'] . '/excluir') ?>" class="form-inline"
                          data-confirmar="Excluir a categoria &quot;<?= e($c['nome']) ?>&quot;?">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn-acao btn-deletar" title="Excluir">✕</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="5" class="td-vazio">Nenhuma categoria encontrada.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php App\Core\View::parcial('paginacao', ['lista' => $lista]); ?>
