<?php
$edit   = $categoria !== null;
$action = $edit ? url('admin/categorias/' . (int)$categoria['id']) : url('admin/categorias');
?>
<div class="admin-page-topo">
    <h2 class="admin-titulo">🏷️ <?= $edit ? 'Editar Categoria' : 'Nova Categoria' ?></h2>
    <a href="<?= url('admin/categorias') ?>" class="btn btn-fantasma">← Voltar</a>
</div>

<div class="form-card">
    <form method="POST" action="<?= $action ?>" class="form-admin" data-validar novalidate>
        <?= csrf_field() ?>
        <div class="campo-grupo">
            <label for="nome">Nome <span class="obrigatorio">*</span></label>
            <input type="text" id="nome" name="nome" value="<?= e(old('nome', $categoria['nome'] ?? '')) ?>" minlength="2" maxlength="80" required>
        </div>
        <div class="campo-grupo">
            <label for="descricao">Descrição</label>
            <textarea id="descricao" name="descricao" rows="3" maxlength="255"><?= e(old('descricao', $categoria['descricao'] ?? '')) ?></textarea>
        </div>
        <div class="form-acoes">
            <button type="submit" class="btn btn-primario"><?= $edit ? 'Salvar alterações' : 'Cadastrar Categoria' ?></button>
            <a href="<?= url('admin/categorias') ?>" class="btn btn-fantasma">Cancelar</a>
        </div>
    </form>
</div>
