<div class="admin-page-topo">
    <h2 class="admin-titulo"><span class="titulo-icone">🎮</span> Gerenciar Jogos</h2>
</div>

<div class="top-bar">
    <form method="GET" action="<?= url('admin/games') ?>" class="form-busca">
        <input type="text" name="buscar" placeholder="Buscar por nome..." value="<?= e($busca) ?>">
        <select name="categoria" aria-label="Filtrar por categoria">
            <option value="0">Todas as categorias</option>
            <?php foreach ($categorias as $c): ?>
                <option value="<?= (int)$c['id'] ?>" <?= $categoriaId === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['nome']) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-secundario">🔍 Buscar</button>
        <?php if ($busca !== '' || $categoriaId): ?><a href="<?= url('admin/games') ?>" class="btn btn-fantasma">✕ Limpar</a><?php endif; ?>
    </form>
    <a href="<?= url('admin/games/novo') ?>" class="btn btn-primario btn-novo">+ Novo Jogo</a>
</div>

<div class="stats-admin">
    <div class="stat"><span class="stat-ico">🕹️</span><div><strong><?= (int)$resumo['jogos'] ?></strong><small>jogos</small></div></div>
    <div class="stat"><span class="stat-ico">📦</span><div><strong><?= (int)$resumo['unidades'] ?></strong><small>unidades em estoque</small></div></div>
    <div class="stat"><span class="stat-ico">💰</span><div><strong><?= preco($resumo['valor']) ?></strong><small>valor em estoque</small></div></div>
</div>

<?php if ($lista['dados']): ?>
<div class="cards-admin">
    <?php foreach ($lista['dados'] as $i => $g):
        $img   = img_url($g['imagem']);
        $pct   = max(4, min(100, ($g['estoque'] / 20) * 100));
        $nivel = $g['estoque'] <= 0 ? 'zero' : ($g['estoque'] <= 5 ? 'baixo' : 'ok');
    ?>
    <article class="card-jogo <?= $g['ativo'] ? '' : 'inativo' ?>" style="--i: <?= $i ?>">
        <div class="card-jogo-img">
            <?php if ($img): ?><img src="<?= e($img) ?>" alt="<?= e($g['titulo']) ?>"><?php else: ?><div class="card-jogo-sem-img">🎮</div><?php endif; ?>
            <span class="card-jogo-id">#<?= (int)$g['id'] ?></span>
            <span class="card-jogo-categoria"><?= e($g['categoria']) ?></span>
        </div>
        <div class="card-jogo-corpo">
            <h3 class="card-jogo-titulo"><?= e($g['titulo']) ?>
                <?php if ($g['destaque']): ?><span class="mini-tag" title="Em destaque">★</span><?php endif; ?>
                <?php if (!$g['ativo']): ?><span class="mini-tag inativo-tag">Oculto</span><?php endif; ?>
            </h3>
            <p class="card-jogo-desc"><?= e($g['descricao']) ?></p>
            <div class="card-jogo-preco-linha">
                <span class="card-jogo-preco"><?= preco($g['preco']) ?></span>
                <span class="card-jogo-estoque <?= $nivel ?>"><?= $g['estoque'] > 0 ? (int)$g['estoque'] . ' em estoque' : 'Esgotado' ?></span>
            </div>
            <div class="barra-estoque"><span class="<?= $nivel ?>" style="width: <?= $pct ?>%"></span></div>

            <div class="card-jogo-acoes">
                <a href="<?= url('admin/games/' . (int)$g['id'] . '/editar') ?>" class="acao acao-editar">✏ Editar</a>
                <form method="POST" action="<?= url('admin/games/' . (int)$g['id'] . '/excluir') ?>" class="form-inline"
                      data-confirmar="Excluir o jogo &quot;<?= e($g['titulo']) ?>&quot;? Esta ação não pode ser desfeita.">
                    <?= csrf_field() ?>
                    <button type="submit" class="acao acao-excluir">🗑 Excluir</button>
                </form>
            </div>
        </div>
    </article>
    <?php endforeach; ?>
</div>
<?php App\Core\View::parcial('paginacao', ['lista' => $lista]); ?>
<?php else: ?>
    <div class="vazio-admin"><span>🕹️</span><p>Nenhum jogo encontrado.</p></div>
<?php endif; ?>
