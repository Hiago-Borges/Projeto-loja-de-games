<?php
$edit = $game !== null;
$v = fn(string $campo, $padrao = '') => old($campo, $edit ? ($game[$campo] ?? $padrao) : $padrao);
$action = $edit ? url('admin/games/' . (int)$game['id']) : url('admin/games');
$img = $edit ? img_url($game['imagem']) : null;
$ativo    = $edit ? (bool)old('ativo', $game['ativo']) : true;
$destaque = $edit ? (bool)old('destaque', $game['destaque']) : false;
// Após erro de validação, os checkboxes não vêm em "old" quando desmarcados.
if (old('titulo') !== '') { $ativo = (bool)old('ativo', 0); $destaque = (bool)old('destaque', 0); }
?>
<div class="admin-page-topo">
    <h2 class="admin-titulo">🎮 <?= $edit ? 'Editar Jogo' : 'Cadastrar Novo Jogo' ?></h2>
    <a href="<?= url('admin/games') ?>" class="btn btn-fantasma">← Voltar</a>
</div>

<div class="form-card">
    <form method="POST" action="<?= $action ?>" enctype="multipart/form-data" class="form-admin" data-validar novalidate>
        <?= csrf_field() ?>

        <div class="campo-grupo">
            <label for="titulo">Título <span class="obrigatorio">*</span></label>
            <input type="text" id="titulo" name="titulo" value="<?= e($v('titulo')) ?>" minlength="2" maxlength="160" required>
        </div>

        <div class="campo-grupo">
            <label for="descricao">Descrição <span class="obrigatorio">*</span></label>
            <textarea id="descricao" name="descricao" rows="4" minlength="10" maxlength="2000" required><?= e($v('descricao')) ?></textarea>
        </div>

        <div class="form-linha">
            <div class="campo-grupo">
                <label for="preco">Preço (R$) <span class="obrigatorio">*</span></label>
                <input type="number" step="0.01" min="0" max="99999.99" id="preco" name="preco" value="<?= e($v('preco')) ?>" required>
            </div>
            <div class="campo-grupo">
                <label for="estoque">Estoque <span class="obrigatorio">*</span></label>
                <input type="number" min="0" step="1" id="estoque" name="estoque" value="<?= e($v('estoque')) ?>" required>
            </div>
        </div>

        <div class="campo-grupo">
            <label for="categoria_id">Categoria <span class="obrigatorio">*</span></label>
            <select id="categoria_id" name="categoria_id" required>
                <option value="">Selecione…</option>
                <?php foreach ($categorias as $c): ?>
                    <option value="<?= (int)$c['id'] ?>" <?= (int)$v('categoria_id') === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['nome']) ?></option>
                <?php endforeach; ?>
            </select>
            <small class="campo-dica">Precisa de uma nova? <a href="<?= url('admin/categorias/novo') ?>">Cadastre aqui</a>.</small>
        </div>

        <div class="campo-grupo">
            <label for="imagem">Capa do jogo</label>
            <?php if ($img): ?>
                <div class="imagem-atual-preview"><img src="<?= e($img) ?>" alt="Capa atual" style="max-width:160px;border-radius:8px"></div>
            <?php endif; ?>
            <input type="file" id="imagem" name="imagem" accept="image/jpeg,image/png,image/webp,image/gif" data-max-mb="2">
            <small class="campo-dica">JPG, PNG, WEBP ou GIF, até 2 MB.<?= $edit ? ' Deixe em branco para manter a atual.' : '' ?></small>
            <img id="previewImagem" alt="" class="preview-upload" hidden>
        </div>

        <div class="form-checks">
            <label class="check"><input type="checkbox" name="ativo" value="1" <?= $ativo ? 'checked' : '' ?>> Ativo (visível na loja)</label>
            <label class="check"><input type="checkbox" name="destaque" value="1" <?= $destaque ? 'checked' : '' ?>> ★ Destaque na página inicial</label>
        </div>

        <div class="form-acoes">
            <button type="submit" class="btn btn-primario"><?= $edit ? 'Salvar alterações' : 'Cadastrar Jogo' ?></button>
            <a href="<?= url('admin/games') ?>" class="btn btn-fantasma">Cancelar</a>
        </div>
    </form>
</div>
