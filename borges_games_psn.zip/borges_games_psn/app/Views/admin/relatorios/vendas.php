<?php $maxDia = max(1, ...array_map(fn($d) => (float)$d['receita'], $porDia ?: [['receita' => 0]])); ?>
<div class="admin-page-topo">
    <h2 class="admin-titulo"><span class="titulo-icone">📈</span> Relatório de vendas</h2>
</div>

<div class="top-bar">
    <form method="GET" action="<?= url('admin/relatorios') ?>" class="form-busca" data-validar>
        <label for="inicio" class="rotulo-inline">De</label>
        <input type="date" id="inicio" name="inicio" value="<?= e($ini) ?>" required>
        <label for="fim" class="rotulo-inline">até</label>
        <input type="date" id="fim" name="fim" value="<?= e($fim) ?>" required>
        <button type="submit" class="btn btn-secundario">Aplicar</button>
    </form>
</div>
<p class="campo-dica" style="margin-bottom:14px">Considera apenas pedidos com status <b>Pago</b>.</p>

<div class="stats-admin">
    <div class="stat"><span class="stat-ico">💰</span><div><strong><?= preco($resumo['receita']) ?></strong><small>receita</small></div></div>
    <div class="stat"><span class="stat-ico">🧾</span><div><strong><?= (int)$resumo['pedidos'] ?></strong><small>pedidos pagos</small></div></div>
    <div class="stat"><span class="stat-ico">🎟️</span><div><strong><?= preco($resumo['ticket']) ?></strong><small>ticket médio</small></div></div>
    <div class="stat"><span class="stat-ico">🕹️</span><div><strong><?= (int)$resumo['itens'] ?></strong><small>jogos vendidos</small></div></div>
</div>

<div class="painel-grid">
    <section class="painel">
        <h3 class="painel-titulo">Receita por dia</h3>
        <?php if ($porDia): ?>
        <table class="tabela-admin tabela-compacta">
            <thead><tr><th>Dia</th><th>Pedidos</th><th>Receita</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($porDia as $d): ?>
                <tr>
                    <td><?= data_br($d['dia'], false) ?></td>
                    <td><?= (int)$d['pedidos'] ?></td>
                    <td><?= preco($d['receita']) ?></td>
                    <td class="barra-celula"><span class="barra-h" style="width: <?= round($d['receita'] / $maxDia * 100) ?>%"></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?><p class="td-vazio">Sem vendas no período.</p><?php endif; ?>
    </section>

    <section class="painel">
        <h3 class="painel-titulo">🏆 Jogos mais vendidos</h3>
        <?php if ($maisVendidos): ?>
        <table class="tabela-admin tabela-compacta">
            <thead><tr><th>Jogo</th><th>Qtd</th><th>Receita</th></tr></thead>
            <tbody>
            <?php foreach ($maisVendidos as $m): ?>
                <tr><td><?= e($m['titulo']) ?></td><td><?= (int)$m['qtd'] ?></td><td><?= preco($m['receita']) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?><p class="td-vazio">Sem vendas no período.</p><?php endif; ?>
    </section>
</div>

<div class="painel-grid">
    <section class="painel">
        <h3 class="painel-titulo">Por categoria</h3>
        <?php if ($porCategoria): ?>
        <table class="tabela-admin tabela-compacta">
            <thead><tr><th>Categoria</th><th>Qtd</th><th>Receita</th></tr></thead>
            <tbody>
            <?php foreach ($porCategoria as $c): ?>
                <tr><td><?= e($c['nome']) ?></td><td><?= (int)$c['qtd'] ?></td><td><?= preco($c['receita']) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?><p class="td-vazio">Sem vendas no período.</p><?php endif; ?>
    </section>

    <section class="painel">
        <h3 class="painel-titulo">Por forma de pagamento</h3>
        <?php if ($porPagamento): ?>
        <table class="tabela-admin tabela-compacta">
            <thead><tr><th>Pagamento</th><th>Pedidos</th><th>Receita</th></tr></thead>
            <tbody>
            <?php foreach ($porPagamento as $p): ?>
                <tr><td><?= e(rotulo_pagamento($p['forma_pagamento'])) ?></td><td><?= (int)$p['pedidos'] ?></td><td><?= preco($p['receita']) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?><p class="td-vazio">Sem vendas no período.</p><?php endif; ?>
    </section>
</div>
