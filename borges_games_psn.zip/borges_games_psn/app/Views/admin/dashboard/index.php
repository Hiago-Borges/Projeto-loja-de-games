<?php
$maxDia = max(1, max(array_column($serie, 'receita')));
?>
<div class="admin-page-topo">
    <h2 class="admin-titulo"><span class="titulo-icone">📊</span> Dashboard</h2>
    <a href="<?= url('admin/relatorios') ?>" class="btn btn-secundario">📈 Relatório completo</a>
</div>

<div class="stats-admin">
    <div class="stat"><span class="stat-ico">💰</span><div><strong><?= preco($resumo30['receita']) ?></strong><small>faturado (30 dias)</small></div></div>
    <div class="stat"><span class="stat-ico">🧾</span><div><strong><?= (int)$resumo30['pedidos'] ?></strong><small>pedidos pagos (30 dias)</small></div></div>
    <div class="stat"><span class="stat-ico">⏳</span><div><strong><?= (int)$porStatus['pendente'] ?></strong><small>pedidos pendentes</small></div></div>
    <div class="stat"><span class="stat-ico">🕹️</span><div><strong><?= (int)$estoque['jogos'] ?></strong><small>jogos cadastrados</small></div></div>
    <div class="stat"><span class="stat-ico">📦</span><div><strong><?= (int)$estoque['unidades'] ?></strong><small>unidades em estoque</small></div></div>
    <div class="stat"><span class="stat-ico">🧑</span><div><strong><?= (int)$totalClientes ?></strong><small>clientes</small></div></div>
</div>

<section class="painel">
    <h3 class="painel-titulo">Vendas nos últimos 30 dias <small>(pedidos pagos)</small></h3>
    <div class="grafico" role="img" aria-label="Gráfico de barras com a receita diária dos últimos 30 dias">
        <?php foreach ($serie as $s): $h = $s['receita'] > 0 ? max(4, round($s['receita'] / $maxDia * 100)) : 2; ?>
            <div class="grafico-col" title="<?= data_br($s['dia'], false) ?>: <?= e(preco($s['receita'])) ?>">
                <span class="grafico-barra <?= $s['receita'] > 0 ? 'cheia' : '' ?>" style="height: <?= $h ?>%"></span>
                <span class="grafico-rotulo"><?= date('d', strtotime($s['dia'])) ?></span>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<div class="painel-grid">
    <section class="painel">
        <h3 class="painel-titulo">🏆 Mais vendidos (30 dias)</h3>
        <?php if ($maisVendidos): ?>
            <table class="tabela-admin tabela-compacta">
                <thead><tr><th>Jogo</th><th>Qtd</th><th>Receita</th></tr></thead>
                <tbody>
                <?php foreach ($maisVendidos as $m): ?>
                    <tr><td><?= e($m['titulo']) ?></td><td><?= (int)$m['qtd'] ?></td><td><?= preco($m['receita']) ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?><p class="td-vazio">Sem vendas no período.</p><?php endif; ?>
    </section>

    <section class="painel">
        <h3 class="painel-titulo">⚠️ Estoque baixo</h3>
        <?php if ($estoqueBaixo): ?>
            <table class="tabela-admin tabela-compacta">
                <thead><tr><th>Jogo</th><th>Estoque</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($estoqueBaixo as $g): ?>
                    <tr>
                        <td><?= e($g['titulo']) ?></td>
                        <td><span class="badge-estoque <?= (int)$g['estoque'] === 0 ? 'badge-baixo' : '' ?>"><?= (int)$g['estoque'] ?></span></td>
                        <td><a class="btn-acao btn-editar" href="<?= url('admin/games/' . (int)$g['id'] . '/editar') ?>" title="Repor">✏</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?><p class="td-vazio">Tudo certo com o estoque. ✅</p><?php endif; ?>
    </section>
</div>

<section class="painel">
    <h3 class="painel-titulo">🧾 Pedidos recentes <a href="<?= url('admin/pedidos') ?>" class="painel-link">ver todos →</a></h3>
    <?php if ($recentes): ?>
        <table class="tabela-admin tabela-compacta">
            <thead><tr><th>#</th><th>Cliente</th><th>Data</th><th>Total</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($recentes as $p): ?>
                <tr>
                    <td><a href="<?= url('admin/pedidos/' . (int)$p['id']) ?>">#<?= (int)$p['id'] ?></a></td>
                    <td><?= e($p['cliente_nome']) ?></td>
                    <td><?= data_br($p['created_at']) ?></td>
                    <td><?= preco($p['total']) ?></td>
                    <td><span class="status status-<?= e($p['status']) ?>"><?= e(rotulo_status($p['status'])) ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?><p class="td-vazio">Nenhum pedido ainda.</p><?php endif; ?>
</section>
