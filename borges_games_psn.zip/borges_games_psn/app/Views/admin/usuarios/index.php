<?php $meuId = (int)\App\Core\Session::usuario()['id']; ?>
<div class="admin-page-topo">
    <h2 class="admin-titulo"><span class="titulo-icone">👥</span> Usuários da equipe</h2>
</div>

<div class="top-bar">
    <form method="GET" action="<?= url('admin/usuarios') ?>" class="form-busca">
        <input type="text" name="buscar" placeholder="Buscar por nome ou e-mail..." value="<?= e($busca) ?>">
        <button type="submit" class="btn btn-secundario">🔍 Buscar</button>
        <?php if ($busca !== ''): ?><a href="<?= url('admin/usuarios') ?>" class="btn btn-fantasma">✕ Limpar</a><?php endif; ?>
    </form>
    <a href="<?= url('admin/usuarios/novo') ?>" class="btn btn-primario">+ Novo Usuário</a>
</div>

<div class="tabela-wrapper">
    <table class="tabela-admin">
        <thead><tr><th>ID</th><th>Nome</th><th>E-mail</th><th>Papel</th><th>Situação</th><th>Criado em</th><th>Ações</th></tr></thead>
        <tbody>
        <?php if ($lista['dados']): foreach ($lista['dados'] as $u): ?>
            <tr>
                <td><?= (int)$u['id'] ?></td>
                <td><?= e($u['nome']) ?><?= (int)$u['id'] === $meuId ? ' <small>(você)</small>' : '' ?></td>
                <td><?= e($u['email']) ?></td>
                <td><span class="badge-tipo badge-<?= $u['papel'] === 'admin' ? 'admin' : 'user' ?>"><?= e(ucfirst($u['papel'])) ?></span></td>
                <td><span class="status <?= $u['ativo'] ? 'status-pago' : 'status-cancelado' ?>"><?= $u['ativo'] ? 'Ativo' : 'Inativo' ?></span></td>
                <td><?= data_br($u['created_at']) ?></td>
                <td class="acoes">
                    <a href="<?= url('admin/usuarios/' . (int)$u['id'] . '/editar') ?>" class="btn-acao btn-editar" title="Editar">✏</a>
                    <?php if ((int)$u['id'] !== $meuId): ?>
                        <form method="POST" action="<?= url('admin/usuarios/' . (int)$u['id'] . '/excluir') ?>" class="form-inline"
                              data-confirmar="Excluir o usuário &quot;<?= e($u['nome']) ?>&quot;?">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn-acao btn-deletar" title="Excluir">✕</button>
                        </form>
                    <?php else: ?>
                        <span class="btn-acao btn-desabilitado" title="Você não pode excluir a própria conta">✕</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="7" class="td-vazio">Nenhum usuário encontrado.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php App\Core\View::parcial('paginacao', ['lista' => $lista]); ?>
