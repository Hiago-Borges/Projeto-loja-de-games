<?php
$edit   = $usuario !== null;
$action = $edit ? url('admin/usuarios/' . (int)$usuario['id']) : url('admin/usuarios');
$ativo  = $edit ? (bool)$usuario['ativo'] : true;
if (old('nome') !== '') $ativo = (bool)old('ativo', 0);
$papel  = old('papel', $usuario['papel'] ?? 'gerente');
?>
<div class="admin-page-topo">
    <h2 class="admin-titulo">👥 <?= $edit ? 'Editar Usuário' : 'Novo Usuário' ?></h2>
    <a href="<?= url('admin/usuarios') ?>" class="btn btn-fantasma">← Voltar</a>
</div>

<div class="form-card">
    <form method="POST" action="<?= $action ?>" class="form-admin" data-validar novalidate>
        <?= csrf_field() ?>
        <div class="form-linha">
            <div class="campo-grupo">
                <label for="nome">Nome completo <span class="obrigatorio">*</span></label>
                <input type="text" id="nome" name="nome" value="<?= e(old('nome', $usuario['nome'] ?? '')) ?>" minlength="3" maxlength="120" required>
            </div>
            <div class="campo-grupo">
                <label for="papel">Papel <span class="obrigatorio">*</span></label>
                <select id="papel" name="papel" required>
                    <option value="gerente" <?= $papel === 'gerente' ? 'selected' : '' ?>>Gerente (tudo, exceto usuários)</option>
                    <option value="admin"   <?= $papel === 'admin'   ? 'selected' : '' ?>>Administrador (acesso total)</option>
                </select>
            </div>
        </div>
        <div class="campo-grupo">
            <label for="email">E-mail <span class="obrigatorio">*</span></label>
            <input type="email" id="email" name="email" value="<?= e(old('email', $usuario['email'] ?? '')) ?>" maxlength="160" required>
        </div>
        <div class="campo-grupo">
            <label for="senha"><?= $edit ? 'Nova senha' : 'Senha' ?> <?php if (!$edit): ?><span class="obrigatorio">*</span><?php endif; ?></label>
            <input type="password" id="senha" name="senha" minlength="6" maxlength="72" autocomplete="new-password" <?= $edit ? '' : 'required' ?>>
            <small class="campo-dica"><?= $edit ? 'Deixe em branco para manter a senha atual. ' : '' ?>Mínimo de 6 caracteres.</small>
        </div>
        <div class="form-checks">
            <label class="check"><input type="checkbox" name="ativo" value="1" <?= $ativo ? 'checked' : '' ?>> Usuário ativo (pode acessar o painel)</label>
        </div>
        <div class="form-acoes">
            <button type="submit" class="btn btn-primario"><?= $edit ? 'Salvar alterações' : 'Cadastrar Usuário' ?></button>
            <a href="<?= url('admin/usuarios') ?>" class="btn btn-fantasma">Cancelar</a>
        </div>
    </form>
</div>
