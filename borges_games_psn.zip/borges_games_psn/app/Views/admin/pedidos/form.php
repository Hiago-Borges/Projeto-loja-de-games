<div class="admin-page-topo">
    <h2 class="admin-titulo">🧾 Novo pedido</h2>
    <a href="<?= url('admin/pedidos') ?>" class="btn btn-fantasma">← Voltar</a>
</div>

<div class="form-card">
    <?php if (!$clientes): ?>
        <div class="alerta alerta-erro">Cadastre um cliente antes de criar pedidos. <a href="<?= url('admin/clientes/novo') ?>">Novo cliente</a></div>
    <?php else: ?>
    <form method="POST" action="<?= url('admin/pedidos') ?>" class="form-admin" data-validar novalidate>
        <?= csrf_field() ?>
        <div class="form-linha">
            <div class="campo-grupo">
                <label for="cliente_id">Cliente <span class="obrigatorio">*</span></label>
                <select id="cliente_id" name="cliente_id" required>
                    <option value="">Selecione…</option>
                    <?php foreach ($clientes as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= (int)old('cliente_id') === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['nome']) ?> — <?= e($c['email']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="campo-grupo">
                <label for="forma_pagamento">Forma de pagamento</label>
                <select id="forma_pagamento" name="forma_pagamento">
                    <?php foreach (['pix', 'cartao', 'boleto'] as $f): ?>
                        <option value="<?= $f ?>" <?= old('forma_pagamento') === $f ? 'selected' : '' ?>><?= rotulo_pagamento($f) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="campo-grupo">
            <label for="status">Status inicial</label>
            <select id="status" name="status">
                <option value="pendente">Pendente</option>
                <option value="pago">Pago</option>
            </select>
        </div>

        <h3 class="painel-titulo">Jogos do pedido</h3>
        <div id="linhas">
            <div class="linha-item">
                <select name="game_id[]" class="sel-game" required>
                    <option value="">Selecione um jogo…</option>
                    <?php foreach ($games as $g): ?>
                        <option value="<?= (int)$g['id'] ?>" data-preco="<?= e($g['preco']) ?>" <?= (int)$g['estoque'] <= 0 ? 'disabled' : '' ?>>
                            <?= e($g['titulo']) ?> — <?= preco($g['preco']) ?> (<?= (int)$g['estoque'] ?> em estoque)
                        </option>
                    <?php endforeach; ?>
                </select>
                <input type="number" name="qtd[]" class="in-qtd" min="1" value="1" aria-label="Quantidade" required>
                <button type="button" class="btn-acao btn-deletar remover-linha" title="Remover linha">✕</button>
            </div>
        </div>
        <button type="button" id="addLinha" class="btn btn-fantasma btn-sm">+ Adicionar outro jogo</button>
        <p class="total-previa">Total estimado: <b id="totalPrevia">R$ 0,00</b></p>

        <div class="form-acoes">
            <button type="submit" class="btn btn-primario">Criar pedido</button>
            <a href="<?= url('admin/pedidos') ?>" class="btn btn-fantasma">Cancelar</a>
        </div>
    </form>

    <script>
    (function () {
        const linhas = document.getElementById('linhas');
        const modelo = linhas.firstElementChild.cloneNode(true);
        const fmt = v => 'R$ ' + v.toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.');

        function recalcular() {
            let total = 0;
            linhas.querySelectorAll('.linha-item').forEach(l => {
                const opt = l.querySelector('.sel-game').selectedOptions[0];
                const q = parseInt(l.querySelector('.in-qtd').value, 10) || 0;
                if (opt && opt.dataset.preco) total += parseFloat(opt.dataset.preco) * q;
            });
            document.getElementById('totalPrevia').textContent = fmt(total);
        }
        document.getElementById('addLinha').addEventListener('click', () => {
            const n = modelo.cloneNode(true);
            n.querySelector('.sel-game').selectedIndex = 0;
            n.querySelector('.in-qtd').value = 1;
            linhas.appendChild(n);
            recalcular();
        });
        linhas.addEventListener('click', e => {
            if (!e.target.classList.contains('remover-linha')) return;
            if (linhas.children.length > 1) { e.target.closest('.linha-item').remove(); recalcular(); }
        });
        linhas.addEventListener('input', recalcular);
        linhas.addEventListener('change', recalcular);
    })();
    </script>
    <?php endif; ?>
</div>
