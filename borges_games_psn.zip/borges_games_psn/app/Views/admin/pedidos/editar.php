<?php $cancelado = $pedido['status'] === 'cancelado'; ?>
<div class="admin-page-topo">
    <h2 class="admin-titulo">✏ Editar pedido #<?= (int)$pedido['id'] ?></h2>
    <a href="<?= url('admin/pedidos/' . (int)$pedido['id']) ?>" class="btn btn-fantasma">← Voltar</a>
</div>

<div class="form-card">
    <p class="campo-info">Cliente: <b><?= e($pedido['cliente_nome']) ?></b> · Total: <b><?= preco($pedido['total']) ?></b> · <?= count($itens) ?> item(ns).
       Os itens de um pedido não são editados: para alterar, cancele e crie outro.</p>

    <?php if ($cancelado): ?>
        <div class="alerta alerta-erro">Pedido cancelado: não pode ser reaberto.</div>
    <?php endif; ?>

    <form method="POST" action="<?= url('admin/pedidos/' . (int)$pedido['id']) ?>" class="form-admin"
          <?= $cancelado ? '' : 'data-confirmar-se="cancelado" data-confirmar="Cancelar o pedido? O estoque dos jogos será devolvido e a ação não pode ser desfeita."' ?>>
        <?= csrf_field() ?>
        <div class="form-linha">
            <div class="campo-grupo">
                <label for="status">Status</label>
                <select id="status" name="status" <?= $cancelado ? 'disabled' : '' ?>>
                    <?php foreach (['pendente', 'pago', 'cancelado'] as $s): ?>
                        <option value="<?= $s ?>" <?= $pedido['status'] === $s ? 'selected' : '' ?>><?= rotulo_status($s) ?></option>
                    <?php endforeach; ?>
                </select>
                <?php if ($cancelado): ?><input type="hidden" name="status" value="cancelado"><?php endif; ?>
            </div>
            <div class="campo-grupo">
                <label for="forma_pagamento">Forma de pagamento</label>
                <select id="forma_pagamento" name="forma_pagamento">
                    <?php foreach (['pix', 'cartao', 'boleto'] as $f): ?>
                        <option value="<?= $f ?>" <?= $pedido['forma_pagamento'] === $f ? 'selected' : '' ?>><?= rotulo_pagamento($f) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-acoes">
            <button type="submit" class="btn btn-primario">Salvar</button>
            <a href="<?= url('admin/pedidos/' . (int)$pedido['id']) ?>" class="btn btn-fantasma">Cancelar</a>
        </div>
    </form>
</div>
