<div class="admin-page-topo">
    <h2 class="admin-titulo">🧾 Pedido #<?= (int)$pedido['id'] ?>
        <span class="status status-<?= e($pedido['status']) ?>"><?= e(rotulo_status($pedido['status'])) ?></span></h2>
    <div>
        <a href="<?= url('admin/pedidos/' . (int)$pedido['id'] . '/editar') ?>" class="btn btn-secundario">✏ Alterar status</a>
        <a href="<?= url('admin/pedidos') ?>" class="btn btn-fantasma">← Voltar</a>
    </div>
</div>

<div class="painel-grid">
    <section class="painel">
        <h3 class="painel-titulo">Cliente</h3>
        <p><b><?= e($pedido['cliente_nome']) ?></b></p>
        <p><?= e($pedido['cliente_email']) ?></p>
        <p><?= e(telefone_fmt($pedido['cliente_telefone'])) ?></p>
    </section>
    <section class="painel">
        <h3 class="painel-titulo">Pedido</h3>
        <p>Data: <b><?= data_br($pedido['created_at']) ?></b></p>
        <p>Pagamento: <b><?= e(rotulo_pagamento($pedido['forma_pagamento'])) ?></b></p>
        <p>Última atualização: <?= data_br($pedido['updated_at']) ?></p>
    </section>
</div>

<div class="tabela-wrapper">
    <table class="tabela-admin">
        <thead><tr><th>Jogo</th><th>Preço unitário</th><th>Qtd</th><th>Subtotal</th></tr></thead>
        <tbody>
        <?php foreach ($itens as $i): ?>
            <tr>
                <td><?= e($i['titulo']) ?></td>
                <td><?= preco($i['preco_unitario']) ?></td>
                <td><?= (int)$i['quantidade'] ?></td>
                <td><?= preco($i['subtotal']) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot><tr><td colspan="3" style="text-align:right"><b>Total</b></td><td><b><?= preco($pedido['total']) ?></b></td></tr></tfoot>
    </table>
</div>
