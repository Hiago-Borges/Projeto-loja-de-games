<div class="admin-page-topo">
    <h2 class="admin-titulo"><span class="titulo-icone">🧾</span> Pedidos</h2>
</div>

<div class="top-bar">
    <form method="GET" action="<?= url('admin/pedidos') ?>" class="form-busca">
        <input type="text" name="buscar" placeholder="Nº do pedido, cliente ou e-mail..." value="<?= e($busca) ?>">
        <select name="status" aria-label="Filtrar por status">
            <option value="">Todos os status</option>
            <?php foreach (['pendente', 'pago', 'cancelado'] as $s): ?>
                <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= rotulo_status($s) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-secundario">🔍 Filtrar</button>
        <?php if ($busca !== '' || $status !== ''): ?><a href="<?= url('admin/pedidos') ?>" class="btn btn-fantasma">✕ Limpar</a><?php endif; ?>
    </form>
    <a href="<?= url('admin/pedidos/novo') ?>" class="btn btn-primario">+ Novo Pedido</a>
</div>

<div class="tabela-wrapper">
    <table class="tabela-admin">
        <thead><tr><th>#</th><th>Cliente</th><th>Data</th><th>Itens</th><th>Pagamento</th><th>Total</th><th>Status</th><th>Ações</th></tr></thead>
        <tbody>
        <?php if ($lista['dados']): foreach ($lista['dados'] as $p): ?>
            <tr>
                <td><a href="<?= url('admin/pedidos/' . (int)$p['id']) ?>"><b>#<?= (int)$p['id'] ?></b></a></td>
                <td><?= e($p['cliente_nome']) ?><br><small><?= e($p['cliente_email']) ?></small></td>
                <td><?= data_br($p['created_at']) ?></td>
                <td><?= (int)$p['qtd_itens'] ?></td>
                <td><?= e(rotulo_pagamento($p['forma_pagamento'])) ?></td>
                <td><?= preco($p['total']) ?></td>
                <td><span class="status status-<?= e($p['status']) ?>"><?= e(rotulo_status($p['status'])) ?></span></td>
                <td class="acoes">
                    <a href="<?= url('admin/pedidos/' . (int)$p['id']) ?>" class="btn-acao" title="Detalhes">👁</a>
                    <a href="<?= url('admin/pedidos/' . (int)$p['id'] . '/editar') ?>" class="btn-acao btn-editar" title="Editar status">✏</a>
                    <form method="POST" action="<?= url('admin/pedidos/' . (int)$p['id'] . '/excluir') ?>" class="form-inline"
                          data-confirmar="Excluir o pedido #<?= (int)$p['id'] ?>? O estoque será devolvido se o pedido não estiver cancelado.">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn-acao btn-deletar" title="Excluir">✕</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="8" class="td-vazio">Nenhum pedido encontrado.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php App\Core\View::parcial('paginacao', ['lista' => $lista]); ?>
