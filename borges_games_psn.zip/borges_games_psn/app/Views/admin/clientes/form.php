<?php
$edit   = $cliente !== null;
$action = $edit ? url('admin/clientes/' . (int)$cliente['id']) : url('admin/clientes');
$ativo  = $edit ? (bool)$cliente['ativo'] : true;
if (old('nome') !== '') $ativo = (bool)old('ativo', 0);
?>
<div class="admin-page-topo">
    <h2 class="admin-titulo">🧑 <?= $edit ? 'Editar Cliente' : 'Novo Cliente' ?></h2>
    <a href="<?= url('admin/clientes') ?>" class="btn btn-fantasma">← Voltar</a>
</div>

<div class="form-card">
    <form method="POST" action="<?= $action ?>" class="form-admin" data-validar novalidate>
        <?= csrf_field() ?>
        <div class="form-linha">
            <div class="campo-grupo">
                <label for="nome">Nome completo <span class="obrigatorio">*</span></label>
                <input type="text" id="nome" name="nome" value="<?= e(old('nome', $cliente['nome'] ?? '')) ?>" minlength="3" maxlength="120" required>
            </div>
            <div class="campo-grupo">
                <label for="telefone">Telefone <span class="obrigatorio">*</span></label>
                <input type="tel" id="telefone" name="telefone" value="<?= e(old('telefone', telefone_fmt($cliente['telefone'] ?? ''))) ?>"
                       placeholder="(38) 99999-9999" data-mask="telefone" data-tipo="telefone" required>
            </div>
        </div>
        <div class="campo-grupo">
            <label for="email">E-mail <span class="obrigatorio">*</span></label>
            <input type="email" id="email" name="email" value="<?= e(old('email', $cliente['email'] ?? '')) ?>" maxlength="160" required>
        </div>
        <div class="campo-grupo">
            <label for="senha"><?= $edit ? 'Nova senha' : 'Senha' ?> <?php if (!$edit): ?><span class="obrigatorio">*</span><?php endif; ?></label>
            <input type="password" id="senha" name="senha" minlength="6" maxlength="72" autocomplete="new-password" <?= $edit ? '' : 'required' ?>>
            <small class="campo-dica"><?= $edit ? 'Deixe em branco para manter a senha atual. ' : '' ?>Mínimo de 6 caracteres.</small>
        </div>
        <div class="form-checks">
            <label class="check"><input type="checkbox" name="ativo" value="1" <?= $ativo ? 'checked' : '' ?>> Conta ativa (pode fazer login)</label>
        </div>
        <div class="form-acoes">
            <button type="submit" class="btn btn-primario"><?= $edit ? 'Salvar alterações' : 'Cadastrar Cliente' ?></button>
            <a href="<?= url('admin/clientes') ?>" class="btn btn-fantasma">Cancelar</a>
        </div>
    </form>
</div>
