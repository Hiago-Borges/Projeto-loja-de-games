<div class="admin-page-topo">
    <h2 class="admin-titulo"><span class="titulo-icone">🧑</span> Clientes</h2>
</div>

<div class="top-bar">
    <form method="GET" action="<?= url('admin/clientes') ?>" class="form-busca">
        <input type="text" name="buscar" placeholder="Buscar por nome, e-mail ou telefone..." value="<?= e($busca) ?>">
        <button type="submit" class="btn btn-secundario">🔍 Buscar</button>
        <?php if ($busca !== ''): ?><a href="<?= url('admin/clientes') ?>" class="btn btn-fantasma">✕ Limpar</a><?php endif; ?>
    </form>
    <a href="<?= url('admin/clientes/novo') ?>" class="btn btn-primario">+ Novo Cliente</a>
</div>

<div class="tabela-wrapper">
    <table class="tabela-admin">
        <thead><tr><th>ID</th><th>Nome</th><th>E-mail</th><th>Telefone</th><th>Pedidos</th><th>Situação</th><th>Cadastro</th><th>Ações</th></tr></thead>
        <tbody>
        <?php if ($lista['dados']): foreach ($lista['dados'] as $c): ?>
            <tr>
                <td><?= (int)$c['id'] ?></td>
                <td><?= e($c['nome']) ?></td>
                <td><?= e($c['email']) ?></td>
                <td><?= e(telefone_fmt($c['telefone'])) ?></td>
                <td><?= (int)$c['total_pedidos'] ?></td>
                <td><span class="status <?= $c['ativo'] ? 'status-pago' : 'status-cancelado' ?>"><?= $c['ativo'] ? 'Ativo' : 'Bloqueado' ?></span></td>
                <td><?= data_br($c['created_at'], false) ?></td>
                <td class="acoes">
                    <a href="<?= url('admin/clientes/' . (int)$c['id'] . '/editar') ?>" class="btn-acao btn-editar" title="Editar">✏</a>
                    <form method="POST" action="<?= url('admin/clientes/' . (int)$c['id'] . '/excluir') ?>" class="form-inline"
                          data-confirmar="Excluir o cliente &quot;<?= e($c['nome']) ?>&quot;?">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn-acao btn-deletar" title="Excluir">✕</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="8" class="td-vazio">Nenhum cliente encontrado.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php App\Core\View::parcial('paginacao', ['lista' => $lista]); ?>
