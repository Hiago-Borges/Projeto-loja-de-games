<?php
namespace App\Core;

/** Upload seguro de imagens (valida tamanho, MIME real e gera nome aleatório). */
final class Upload
{
    private const TIPOS = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];

    /** @return string|null nome do arquivo salvo, ou null se nenhum arquivo foi enviado. */
    public static function imagem(?array $arq): ?string
    {
        if (!$arq || ($arq['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;

        if ($arq['error'] !== UPLOAD_ERR_OK) {
            throw new \RuntimeException('Falha no envio da imagem (código ' . $arq['error'] . ').');
        }
        if ($arq['size'] > Config::get('app.upload_max')) {
            throw new \RuntimeException('A imagem excede o limite de ' . (Config::get('app.upload_max') / 1024 / 1024) . ' MB.');
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($arq['tmp_name']);
        if (!isset(self::TIPOS[$mime]) || @getimagesize($arq['tmp_name']) === false) {
            throw new \RuntimeException('Formato de imagem não suportado. Use JPG, PNG, WEBP ou GIF.');
        }

        $pasta = BASE_PATH . '/public/uploads/';
        if (!is_dir($pasta)) mkdir($pasta, 0755, true);

        $nome = 'game_' . bin2hex(random_bytes(8)) . '.' . self::TIPOS[$mime];
        if (!move_uploaded_file($arq['tmp_name'], $pasta . $nome)) {
            throw new \RuntimeException('Não foi possível salvar a imagem no servidor.');
        }
        return $nome;
    }

    public static function remover(?string $nome): void
    {
        if (!$nome) return;
        $caminho = BASE_PATH . '/public/uploads/' . basename($nome);
        if (is_file($caminho)) @unlink($caminho);
    }
}
