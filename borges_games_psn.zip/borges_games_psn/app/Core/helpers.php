<?php
// Funções auxiliares globais usadas nas views e controllers.

use App\Core\Session;

/** Escapa HTML (proteção contra XSS). Use em TODA saída de dados. */
function e(mixed $v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Caminho base da aplicação (ex.: /borges_games_psn/public). */
function base_url(): string
{
    static $base = null;
    if ($base === null) {
        $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
    }
    return $base;
}

function url(string $caminho = ''): string
{
    return base_url() . '/' . ltrim($caminho, '/');
}

function redirect(string $caminho): never
{
    header('Location: ' . url($caminho));
    exit;
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(Session::csrf()) . '">';
}

function old(string $campo, mixed $padrao = ''): mixed
{
    return Session::old($campo, $padrao);
}

function preco(float|int|string|null $v): string
{
    return 'R$ ' . number_format((float)$v, 2, ',', '.');
}

function parcela(float|int|string|null $v): string
{
    return '3x de ' . preco(((float)$v) / 3) . ' sem juros';
}

function data_br(?string $data, bool $hora = true): string
{
    if (!$data) return '—';
    $t = strtotime($data);
    return $t ? date($hora ? 'd/m/Y H:i' : 'd/m/Y', $t) : '—';
}

/** URL pública da imagem do jogo, ou null se não existir no disco. */
function img_url(?string $nome): ?string
{
    if (!$nome) return null;
    $nome = basename($nome);
    return is_file(BASE_PATH . '/public/uploads/' . $nome) ? url('uploads/' . $nome) : null;
}

function telefone_fmt(?string $t): string
{
    $d = preg_replace('/\D/', '', (string)$t);
    if (strlen($d) === 11) return sprintf('(%s) %s-%s', substr($d, 0, 2), substr($d, 2, 5), substr($d, 7));
    if (strlen($d) === 10) return sprintf('(%s) %s-%s', substr($d, 0, 2), substr($d, 2, 4), substr($d, 6));
    return (string)$t;
}

function rotulo_status(string $s): string
{
    return ['pendente' => 'Pendente', 'pago' => 'Pago', 'cancelado' => 'Cancelado'][$s] ?? ucfirst($s);
}

function rotulo_pagamento(string $p): string
{
    return ['pix' => 'PIX', 'cartao' => 'Cartão de crédito', 'boleto' => 'Boleto'][$p] ?? $p;
}

/** Marca o link atual no menu. */
function rota_ativa(string $prefixo): string
{
    $caminho = '/' . trim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
    $base    = base_url();
    if ($base !== '' && str_starts_with($caminho, $base)) $caminho = substr($caminho, strlen($base));
    $caminho = '/' . trim($caminho, '/');
    return str_starts_with($caminho, $prefixo) ? 'ativo' : '';
}
