<?php
namespace App\Core;

/**
 * Validação de formulários no servidor.
 * Uso: Validator::validar($_POST, ['nome' => 'required|max:120'], ['nome' => 'Nome']);
 */
final class Validator
{
    public static function validar(array $dados, array $regras, array $rotulos = []): array
    {
        $erros = [];
        foreach ($regras as $campo => $lista) {
            $rotulo = $rotulos[$campo] ?? ucfirst($campo);
            $valor  = isset($dados[$campo]) && is_string($dados[$campo]) ? trim($dados[$campo]) : ($dados[$campo] ?? '');

            foreach (explode('|', $lista) as $regra) {
                [$nome, $arg] = array_pad(explode(':', $regra, 2), 2, null);
                $vazio = ($valor === '' || $valor === null);

                if ($nome !== 'required' && $vazio) continue; // regras opcionais só valem se preenchido

                $msg = match ($nome) {
                    'required' => $vazio ? "$rotulo é obrigatório." : null,
                    'email'    => !filter_var($valor, FILTER_VALIDATE_EMAIL) ? "$rotulo inválido." : null,
                    'min'      => mb_strlen((string)$valor) < (int)$arg ? "$rotulo deve ter no mínimo $arg caracteres." : null,
                    'max'      => mb_strlen((string)$valor) > (int)$arg ? "$rotulo deve ter no máximo $arg caracteres." : null,
                    'numeric'  => !is_numeric(str_replace(',', '.', (string)$valor)) ? "$rotulo deve ser um número." : null,
                    'int'      => filter_var($valor, FILTER_VALIDATE_INT) === false ? "$rotulo deve ser um número inteiro." : null,
                    'min_val'  => (float)str_replace(',', '.', (string)$valor) < (float)$arg ? "$rotulo deve ser no mínimo $arg." : null,
                    'max_val'  => (float)str_replace(',', '.', (string)$valor) > (float)$arg ? "$rotulo deve ser no máximo $arg." : null,
                    'same'     => $valor !== ($dados[$arg] ?? null) ? "$rotulo não confere." : null,
                    'in'       => !in_array($valor, explode(',', (string)$arg), true) ? "$rotulo inválido." : null,
                    'telefone' => !preg_match('/^\d{10,11}$/', preg_replace('/\D/', '', (string)$valor)) ? "$rotulo inválido. Use DDD + número." : null,
                    default    => null,
                };
                if ($msg) { $erros[$campo] = $msg; break; }
            }
        }
        return $erros;
    }
}
