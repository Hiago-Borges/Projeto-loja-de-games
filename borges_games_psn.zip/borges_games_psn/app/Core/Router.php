<?php
namespace App\Core;

/**
 * Roteador do MVC (front controller).
 * Mapeia  MÉTODO + URL  →  Controller@ação  e aplica middlewares.
 */
final class Router
{
    private array $rotas = [];

    public function get(string $padrao, array $acao, array $mw = []): void  { $this->add('GET', $padrao, $acao, $mw); }
    public function post(string $padrao, array $acao, array $mw = []): void { $this->add('POST', $padrao, $acao, $mw); }

    private function add(string $metodo, string $padrao, array $acao, array $mw): void
    {
        // {id} vira um grupo numérico
        $regex = '#^' . preg_replace('#\{(\w+)\}#', '(\d+)', $padrao) . '$#';
        $this->rotas[] = compact('metodo', 'regex', 'acao', 'mw');
    }

    public function despachar(): void
    {
        $metodo  = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $caminho = $this->caminhoRequisicao();

        foreach ($this->rotas as $r) {
            if ($r['metodo'] !== $metodo || !preg_match($r['regex'], $caminho, $m)) continue;
            array_shift($m);

            if ($metodo === 'POST' && !Session::validarCsrf($_POST['_csrf'] ?? null)) {
                $this->erro(419, 'Sessão expirada. Volte e tente novamente.');
            }
            foreach ($r['mw'] as $mw) $this->middleware($mw);

            [$classe, $acao] = $r['acao'];
            $controller = new $classe();
            $controller->$acao(...array_map('intval', $m));
            return;
        }
        $this->erro(404, 'Página não encontrada.');
    }

    private function caminhoRequisicao(): string
    {
        $uri   = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $uri   = rawurldecode($uri);
        $base  = base_url();                 // /borges_games_psn/public
        $raiz  = str_replace('\\', '/', dirname($base)); // /borges_games_psn

        if ($base !== '' && str_starts_with($uri, $base)) {
            $uri = substr($uri, strlen($base));
        } elseif (!in_array($raiz, ['', '.', '/'], true) && str_starts_with($uri, $raiz)) {
            $uri = substr($uri, strlen($raiz));   // acesso pela raiz do projeto via .htaccess
        }
        return '/' . trim($uri, '/');
    }

    private function middleware(string $nome): void
    {
        switch ($nome) {
            case 'guest':
                if (Session::logado()) redirect(Session::ehAdmin() ? 'admin' : '');
                break;
            case 'auth':
                if (!Session::logado()) $this->exigirLogin();
                break;
            case 'cliente':
                if (!Session::logado()) $this->exigirLogin();
                if (!Session::ehCliente()) $this->erro(403, 'Esta área é exclusiva para clientes.');
                break;
            case 'admin':
                if (!Session::logado()) $this->exigirLogin();
                if (!Session::ehAdmin()) $this->erro(403, 'Acesso negado. Apenas administradores podem acessar o painel.');
                break;
            case 'superadmin':
                if (!Session::logado()) $this->exigirLogin();
                if (!Session::ehAdmin() || (Session::usuario()['papel'] ?? '') !== 'admin') {
                    $this->erro(403, 'Apenas administradores (papel "admin") podem gerenciar usuários.');
                }
                break;
        }
    }

    private function exigirLogin(): never
    {
        Session::flash('erro', 'Faça login para continuar.');
        if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
            Session::set('url_destino', $_SERVER['REQUEST_URI'] ?? '');
        }
        redirect('login');
    }

    private function erro(int $codigo, string $mensagem): never
    {
        http_response_code($codigo);
        View::render('erro/erro', ['codigo' => $codigo, 'mensagem' => $mensagem, 'titulo' => "Erro $codigo"], 'publico');
        exit;
    }
}
