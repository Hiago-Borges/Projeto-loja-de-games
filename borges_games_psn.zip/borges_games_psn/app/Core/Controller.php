<?php
namespace App\Core;

abstract class Controller
{
    protected function view(string $view, array $dados = [], string $layout = 'publico'): void
    {
        View::render($view, $dados, $layout);
    }

    protected function redirecionar(string $caminho): never
    {
        redirect($caminho);
    }

    /** Valor de $_POST sem espaços nas pontas. */
    protected function post(string $campo, string $padrao = ''): string
    {
        $v = $_POST[$campo] ?? $padrao;
        return is_string($v) ? trim($v) : $padrao;
    }

    protected function get(string $campo, string $padrao = ''): string
    {
        $v = $_GET[$campo] ?? $padrao;
        return is_string($v) ? trim($v) : $padrao;
    }

    /** Falha de validação: guarda o que foi digitado, mostra os erros e volta ao formulário. */
    protected function voltarComErros(array $erros, string $destino): never
    {
        Session::guardarOld($_POST);
        foreach ($erros as $msg) Session::flash('erro', $msg);
        redirect($destino);
    }

    protected function naoEncontrado(): never
    {
        http_response_code(404);
        View::render('erro/erro', ['codigo' => 404, 'mensagem' => 'Registro não encontrado.', 'titulo' => 'Não encontrado'], 'publico');
        exit;
    }
}
