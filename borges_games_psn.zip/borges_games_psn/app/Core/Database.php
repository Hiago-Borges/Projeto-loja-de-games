<?php
namespace App\Core;

use PDO;
use PDOException;

/** Conexão única (Singleton) com o MySQL via PDO. */
final class Database
{
    private static ?PDO $pdo = null;

    public static function conectar(): PDO
    {
        if (self::$pdo === null) {
            $c   = Config::get('db');
            $dsn = "mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset={$c['charset']}";
            try {
                self::$pdo = new PDO($dsn, $c['user'], $c['pass'], [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]);
            } catch (PDOException $e) {
                http_response_code(500);
                $msg = Config::get('app.debug') ? $e->getMessage() : 'Erro ao conectar ao banco de dados.';
                exit('<h1>Erro de conexão</h1><p>' . htmlspecialchars($msg) . '</p>'
                    . '<p>Verifique <code>config/config.php</code> e se o banco foi importado (<code>database/banco.sql</code>).</p>');
            }
        }
        return self::$pdo;
    }
}
