<?php
namespace App\Core;

/** Controle de sessão, flash messages, CSRF e usuário autenticado. */
final class Session
{
    public static function iniciar(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_set_cookie_params([
                'lifetime' => 0,
                'path'     => '/',
                'httponly' => true,
                'samesite' => 'Lax',
                'secure'   => !empty($_SERVER['HTTPS']),
            ]);
            session_start();
        }
    }

    public static function set(string $k, mixed $v): void { $_SESSION[$k] = $v; }
    public static function get(string $k, mixed $padrao = null): mixed { return $_SESSION[$k] ?? $padrao; }
    public static function remover(string $k): void { unset($_SESSION[$k]); }

    // ---- flash (mensagem que aparece uma única vez) ----
    public static function flash(string $tipo, string $msg): void { $_SESSION['_flash'][] = ['tipo' => $tipo, 'msg' => $msg]; }
    public static function pegarFlash(): array
    {
        $f = $_SESSION['_flash'] ?? [];
        unset($_SESSION['_flash']);
        return $f;
    }

    // ---- old input (repreenche o formulário após erro) ----
    public static function guardarOld(array $dados): void
    {
        unset($dados['senha'], $dados['senha_confirmacao'], $dados['_csrf']);
        $_SESSION['_old'] = $dados;
    }
    public static function old(string $campo, mixed $padrao = ''): mixed
    {
        return $_SESSION['_old_atual'][$campo] ?? $padrao;
    }
    public static function carregarOld(): void
    {
        $_SESSION['_old_atual'] = $_SESSION['_old'] ?? [];
        unset($_SESSION['_old']);
    }

    // ---- CSRF ----
    public static function csrf(): string
    {
        return $_SESSION['_csrf'] ??= bin2hex(random_bytes(32));
    }
    public static function validarCsrf(?string $token): bool
    {
        return is_string($token) && isset($_SESSION['_csrf']) && hash_equals($_SESSION['_csrf'], $token);
    }

    // ---- autenticação ----
    public static function login(array $usuario, string $tipo): void
    {
        session_regenerate_id(true); // evita session fixation
        $_SESSION['auth'] = [
            'id'    => (int)$usuario['id'],
            'nome'  => $usuario['nome'],
            'email' => $usuario['email'],
            'tipo'  => $tipo,                      // 'admin' | 'cliente'
            'papel' => $usuario['papel'] ?? null,  // 'admin' | 'gerente' (somente staff)
        ];
    }
    public static function usuario(): ?array { return $_SESSION['auth'] ?? null; }
    public static function logado(): bool { return isset($_SESSION['auth']); }
    public static function ehAdmin(): bool { return (self::usuario()['tipo'] ?? '') === 'admin'; }
    public static function ehCliente(): bool { return (self::usuario()['tipo'] ?? '') === 'cliente'; }
    public static function logout(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }
}
