<?php
namespace App\Core;

use PDO;
use PDOStatement;

/** Base dos Models: acesso ao PDO e utilitários de consulta (sempre com prepared statements). */
abstract class Model
{
    protected PDO $pdo;
    protected string $tabela;

    public function __construct()
    {
        $this->pdo = Database::conectar();
    }

    protected function executar(string $sql, array $params = []): PDOStatement
    {
        $st = $this->pdo->prepare($sql);
        foreach ($params as $nome => $valor) {
            $tipo = match (true) {
                is_int($valor)  => PDO::PARAM_INT,
                is_bool($valor) => PDO::PARAM_BOOL,
                is_null($valor) => PDO::PARAM_NULL,
                default         => PDO::PARAM_STR,
            };
            $st->bindValue(is_int($nome) ? $nome + 1 : ':' . ltrim($nome, ':'), $valor, $tipo);
        }
        $st->execute();
        return $st;
    }

    protected function todos(string $sql, array $params = []): array
    {
        return $this->executar($sql, $params)->fetchAll();
    }

    protected function um(string $sql, array $params = []): ?array
    {
        $r = $this->executar($sql, $params)->fetch();
        return $r === false ? null : $r;
    }

    protected function valor(string $sql, array $params = []): mixed
    {
        $r = $this->executar($sql, $params)->fetchColumn();
        return $r === false ? null : $r;
    }

    public function buscar(int $id): ?array
    {
        return $this->um("SELECT * FROM {$this->tabela} WHERE id = :id", ['id' => $id]);
    }

    public function excluir(int $id): bool
    {
        return $this->executar("DELETE FROM {$this->tabela} WHERE id = :id", ['id' => $id])->rowCount() > 0;
    }

    public function contar(): int
    {
        return (int)$this->valor("SELECT COUNT(*) FROM {$this->tabela}");
    }

    /** Monta o array de paginação padrão usado pelas listagens. */
    protected function paginar(string $sqlLista, string $sqlTotal, array $params, int $pagina, int $porPagina): array
    {
        $total   = (int)$this->valor($sqlTotal, $params);
        $paginas = max(1, (int)ceil($total / $porPagina));
        $pagina  = min(max(1, $pagina), $paginas);
        $dados   = $this->todos($sqlLista . ' LIMIT :_lim OFFSET :_off',
                    $params + ['_lim' => $porPagina, '_off' => ($pagina - 1) * $porPagina]);
        return ['dados' => $dados, 'total' => $total, 'pagina' => $pagina, 'paginas' => $paginas];
    }

    /** Código de erro de chave estrangeira (registro em uso). */
    public static function violouFk(\PDOException $e): bool
    {
        return in_array((int)($e->errorInfo[1] ?? 0), [1451, 1452], true);
    }
}
