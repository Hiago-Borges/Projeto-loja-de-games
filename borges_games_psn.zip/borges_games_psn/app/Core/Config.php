<?php
namespace App\Core;

final class Config
{
    private static ?array $dados = null;

    /** Config::get('db.host') ou Config::get('app.nome') */
    public static function get(string $chave, mixed $padrao = null): mixed
    {
        self::$dados ??= require BASE_PATH . '/config/config.php';
        $valor = self::$dados;
        foreach (explode('.', $chave) as $parte) {
            if (!is_array($valor) || !array_key_exists($parte, $valor)) return $padrao;
            $valor = $valor[$parte];
        }
        return $valor;
    }
}
