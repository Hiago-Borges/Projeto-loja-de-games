<?php
namespace App\Core;

use App\Models\Game;

/** Carrinho de compras simples, guardado na sessão: [game_id => quantidade]. */
final class Carrinho
{
    private static function dados(): array { return Session::get('carrinho', []); }

    public static function adicionar(int $gameId, int $qtd = 1): void
    {
        $c = self::dados();
        $c[$gameId] = ($c[$gameId] ?? 0) + max(1, $qtd);
        Session::set('carrinho', $c);
    }

    public static function atualizar(int $gameId, int $qtd): void
    {
        $c = self::dados();
        if ($qtd <= 0) unset($c[$gameId]); else $c[$gameId] = $qtd;
        Session::set('carrinho', $c);
    }

    public static function remover(int $gameId): void { self::atualizar($gameId, 0); }
    public static function limpar(): void { Session::remover('carrinho'); }
    public static function quantidadeTotal(): int { return array_sum(self::dados()); }
    public static function bruto(): array { return self::dados(); }

    /** Itens completos (dados atuais do banco), com subtotal; ajusta para o estoque disponível. */
    public static function itens(): array
    {
        $ids = array_keys(self::dados());
        if (!$ids) return [];

        $itens = [];
        foreach ((new Game())->buscarVarios($ids) as $g) {
            if (!$g['ativo'] || $g['estoque'] <= 0) { self::remover((int)$g['id']); continue; }
            $qtd = min((int)self::dados()[$g['id']], (int)$g['estoque']);
            $itens[] = $g + ['qtd' => $qtd, 'subtotal' => $qtd * (float)$g['preco']];
        }
        return $itens;
    }

    public static function total(array $itens): float
    {
        return array_sum(array_column($itens, 'subtotal'));
    }
}
