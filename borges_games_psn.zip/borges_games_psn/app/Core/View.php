<?php
namespace App\Core;

final class View
{
    /**
     * Renderiza app/Views/{$__view}.php dentro de app/Views/layouts/{$__layout}.php
     * (nomes com "__" para não colidirem com variáveis enviadas pelos controllers).
     */
    public static function render(string $__view, array $__dados = [], string $__layout = 'publico'): void
    {
        $__arquivo = BASE_PATH . '/app/Views/' . $__view . '.php';
        if (!is_file($__arquivo)) throw new \RuntimeException("View não encontrada: $__view");

        extract($__dados, EXTR_SKIP);
        ob_start();
        require $__arquivo;
        $conteudo = ob_get_clean();

        $titulo ??= Config::get('app.nome');
        require BASE_PATH . '/app/Views/layouts/' . $__layout . '.php';
    }

    /** Inclui um parcial (ex.: paginação) dentro de uma view. */
    public static function parcial(string $__nome, array $__dados = []): void
    {
        extract($__dados, EXTR_SKIP);
        require BASE_PATH . '/app/Views/parciais/' . $__nome . '.php';
    }
}
